package ch10_extends_interface.lol;

public class Champion {
	String name;
	int damage;
	int hp;
	
	public Champion(String name, int damage, int hp) {
		super();
		this.name = name;
		this.damage = damage;
		this.hp = hp;
	}
	
}
