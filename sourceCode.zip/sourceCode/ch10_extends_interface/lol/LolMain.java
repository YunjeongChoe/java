package ch10_extends_interface.lol;

public class LolMain {

	public static void main(String[] args) {
		Shen shen = new Shen("쉔", 50, 500);
		
		shen.skillQ();
	}

}
