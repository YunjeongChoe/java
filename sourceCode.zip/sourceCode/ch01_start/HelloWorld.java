package ch01_start;

public class HelloWorld {

	public static void main(String[] args) {
		// 단축키 [Ctrl + D] : 커서가 위치한 한줄 삭제
		System.out.println("Hello world!!");
		
		// 단축키 [Ctrl + Space] : 자동완성
		System.out.println();

		// 단축키 [Ctrl + Alt + 화살표 아래] : copy line
		System.out.println();
		System.out.println();
		
		// 단축키 [Ctrl + Y] : 실행취소한 것 다시 앞으로 돌리기
		
	}

}
