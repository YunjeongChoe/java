package ch03_system_inout;

import java.util.Scanner;

public class SystemMain {
	public static void main(String[] args) {
		// 자동 줄 맞추기
		// 단축키 [Ctrl + Shift + F]
		// (단, 현재 클래스에 에러가 없어야 동작)
		
		// 콘솔에 텍스트 출력하기
		// println() 콘솔창에 출력 후 줄바꿈(개행문자)
		// 을 넣어준다.
		System.out.println("이미 알고 있는데요?");
		System.out.println();	// 개행문자만 들어간다.
		System.out.println("아 정말요?");
		
		// print() 괄호안 텍스트를 콘솔에 출력
		// 개행문자가 들어가지 않음
		System.out.print("불편한데..");
		System.out.print("불불불");
		
		System.out.println("\n=====================\n");
		
		// 제어문자
		// 문자열 내에 역슬래시(\)를 이용하여
		// 특정 기능을 사용할 수 있다.
		
		// \t 탭
		System.out.println("일\t월\t화\t수\t목\t금\t토");
		System.out.println("1\t2\t3\t4\t5\t6\t7");
		
		// \n 줄바꿈
		System.out.print("나도 println이 되고 싶어\n");
		
		// 기능을 가지는 문자(\, ", ')를 콘솔창에
		// 출력하고 싶다면 앞에 \를 붙인다.
		System.out.println("제어문자는 앞에 \\를 붙인다.");
		System.out.println("소크라테스: \"너 자신을 알라\"");
		
		// 특수문자도 출력 가능하다.
		System.out.println("♤");
		
		System.out.println("\n======================\n");
		
		// printf() 은 포맷 문자열(format string)
		// 과 함께 사용
		System.out.printf("%d명이 수업을 듣고 있습니다.\n", 21);
		System.out.printf("%d명이 수업을 %d시간째 듣고 있습니다.\n", 21, 3);
		System.out.printf("%d명이 %s을 듣고 있습니다.\n", 21, "수업");

		// 예시
		System.out.printf("%03d장 표준입출력\n", 3);
		System.out.printf("%.03f \n", 3.141592);
		System.out.printf("%.03f \n", 3.14);
		
		System.out.println("\n=========== 표준 입력 =============\n");
		
		// 표준 입력
		Scanner scanner = new Scanner(System.in); 
		System.out.println("이름을 입력해주세요");
		System.out.print(">>> ");
		String name = scanner.nextLine();
		System.out.println(name + ": 더워!! 습해!!");
		
		System.out.println("에어컨 희망 온도를 입력해주세요");
		System.out.print(">>> ");
		// scanner.nextInt() 은 사용하지 마세요.
//		int temperature = scanner.nextInt();
		int temp = Integer.parseInt(scanner.nextLine());
		System.out.println("희망온도: " + (temp + 1));
		
		System.out.println("냉방/난방 입력해주세요");
		System.out.print(">>> ");
		String airconMode = scanner.nextLine();
		System.out.println("모드: " + airconMode);
		
		// 키보드 입력을 받는 통로를 열어
		// 두었건 것을 닫는다.
		// (안닫아도 큰 문제가 생기지는 않는다)
//		scanner.close();
		
	}
}
