package chanung.submit11;

import java.util.ArrayList;

public class ProductMain {

	public static void main(String[] args) {
		// 상태(state)에 제품명과 가격을 가지는
		// Product 클래스를 만들기
		
		Product ref = new Product("냉장고", 2000000);
		Product tv = new Product("TV", 1000000);
		Product air = new Product("에어컨", 800000);
		Product com = new Product("컴퓨터", 1300000);
		Product fan = new Product("선풍기", 100000);
		
		ArrayList<Product> prodList = new ArrayList<>();
		prodList.add(ref);
		prodList.add(tv);
		prodList.add(air);
		prodList.add(com);
		prodList.add(fan);
		
		// 정렬
		for(int k = 0; k < prodList.size(); k++) {
			for(int i = 0; i < prodList.size()-1-k; i++) {
				// i > i+1 하면 오름차순
				// i < i+1 하면 내림차순
				if(prodList.get(i).getPrice() > prodList.get(i+1).getPrice()) {	
					Product tmp = prodList.get(i);
					prodList.set(i, prodList.get(i+1));
					prodList.set(i+1, tmp);
				}
			}
		}
		
		for(int i = 0; i < prodList.size(); i++) {
			System.out.println(prodList.get(i).toString());
		}
		
		// TV 찾기
		for(int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i).getName().equals("TV")) {
				System.out.println(i);
			}
		}
		
	}

}
