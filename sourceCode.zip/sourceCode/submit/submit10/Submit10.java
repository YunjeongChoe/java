package chanung.submit10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class Submit10 {

	public static void main(String[] args) {
		// makeLotto()를 ArrayList와
		// HashSet을 이용해서 만들어보세요.
		
		ArrayList<Integer> myLotto = makeLotto();
		System.out.println(myLotto);
		
		System.out.println("\n==========================\n");
		
		HashMap<String, String> infoMap = new HashMap<>();
		
		infoMap.put("a001", "1234a");
		infoMap.put("b001", "1234b");
		infoMap.put("c001", "1234c");
		infoMap.put("d001", "1234d");
		infoMap.put("e001", "1234e");
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("아이디를 입력해주세요");
		System.out.print(">>> ");
		String id = sc.nextLine();
		System.out.println("비밀번호를 입력하세요");
		System.out.print(">>> ");
		String pw = sc.nextLine();
		
		if(infoMap.get(id) != null) {
			// 아이디가 존재하는 경우
			if(infoMap.get(id).equals(pw)) {
				System.out.println("로그인 성공");
			}else {
				System.out.println("비밀번호가 틀렸습니다.");
			}
		}else {
			// 아이디가 존재하지 않음
			System.out.println("존재하지 않는 아이디입니다.");
		}
		
		
		
	} // main 끝
	
	static ArrayList<Integer> makeLotto(){
		HashSet<Integer> tempSet = new HashSet<>();
		while(tempSet.size() < 6) {
			int randInt = (int)(Math.random()*45) + 1;
			tempSet.add(randInt);
//			if(tempSet.size() == 6) {
//				break;
//			}
		}
		
		ArrayList<Integer> resultList = new ArrayList<>();
		resultList.addAll(tempSet);
		
		Collections.sort(resultList);
		return resultList;
	}
	
	
	

}
