package chanung.submit15.model;

public class BoardVO {
	private int no;
	private String boardTitle;
	private String boardContent;
	private String boardAuthor;
	private String boardDate;
	
	public BoardVO() {
		
	}
	
	public BoardVO(int no, String boardTitle, String boardContent, String boardAuthor, String boardDate) {
		super();
		this.no = no;
		this.boardTitle = boardTitle;
		this.boardContent = boardContent;
		this.boardAuthor = boardAuthor;
		this.boardDate = boardDate;
	}

	@Override
	public String toString() {
		return "[ " + no + " | " + boardTitle + " | "
				+ boardAuthor + " | " + boardDate + " ]";
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}

	public String getBoardContent() {
		return boardContent;
	}

	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}

	public String getBoardAuthor() {
		return boardAuthor;
	}

	public void setBoardAuthor(String boardAuthor) {
		this.boardAuthor = boardAuthor;
	}

	public String getBoardDate() {
		return boardDate;
	}

	public void setBoardDate(String boardDate) {
		this.boardDate = boardDate;
	}
	
}
