package chanung.submit15.service;

import java.sql.Connection;
import java.sql.SQLException;

import chanung.submit15.dao.MemberDao;
import chanung.submit15.jdbc.ConnectionPool;
import chanung.submit15.model.MemberVO;

public class MemberService {
	private MemberDao dao = MemberDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static MemberService instance = new MemberService();
	
	public static MemberService getInstance() {
		return instance;
	}
	
	private MemberService() {
		
	}
	
	// 회원가입 (INSERT)
	public int registMem(MemberVO mem) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.registMem(conn, mem);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return 0;
	}
	
	// 중복체크용
	public boolean dupleCheck(String id) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.dupleCheck(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return false;
	}
	
	// 로그인용
	public MemberVO loginMem(String id) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.loginMem(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return null;
	}
	
	
	
	
}
