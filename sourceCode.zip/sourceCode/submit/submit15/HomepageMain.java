package chanung.submit15;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import chanung.submit15.model.BoardVO;
import chanung.submit15.model.MemberVO;
import chanung.submit15.service.BoardService;
import chanung.submit15.service.MemberService;

public class HomepageMain {

	public static void main(String[] args) {
		MemberService memService = MemberService.getInstance();
		BoardService boardService = BoardService.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("행동을 선택해주세요.");
			System.out.println("1. 회원가입 | 2. 로그인 | 3. 종료");
			System.out.print(">>> ");
			
			int command = 0;
			try {
				command = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("숫자만 입력해주세요");
				continue;
			}
			
			if(command == 1) {
				// 회원가입
				System.out.println("아이디를 입력해주세요");
				System.out.print(">>> ");
				String id = sc.nextLine();
				System.out.println("비밀번호를 입력해주세요");
				System.out.print(">>> ");
				String pw = sc.nextLine();
				
				// 중복체크
				boolean isDuple = memService.dupleCheck(id);
				
				if(isDuple) {
					System.out.println("중복된 아이디 입니다.");
				}else {
					// 회원가입 진행
					int cnt = memService.registMem(new MemberVO(id, pw));
					
					if(cnt > 0) {
						System.out.println("회원가입이 성공적으로 이루어졌습니다.");
					}else {
						System.out.println("회원가입 실패. 관리자 문의하세요");
					}
				}
				
			}else if(command == 2) {
				// 로그인
				System.out.println("아이디를 입력해주세요");
				System.out.print(">>> ");
				String id = sc.nextLine();
				System.out.println("비밀번호를 입력해주세요");
				System.out.print(">>> ");
				String pw = sc.nextLine();
				
				MemberVO login = memService.loginMem(id);
				
				if(login != null) {
					if(login.getMemPw().equals(pw)) {
						// 로그인 성공
						System.out.println(login.getMemId() + "님 환영합니다.");
						
						// TODO 게시판 입장
						while(true) {
							ArrayList<BoardVO> boardList = boardService.getBoardList();
							for(int i = 0; i < boardList.size(); i++) {
								System.out.println(boardList.get(i).toString());
							}
							
							System.out.println("행동을 선택해주세요");
							System.out.println("1. 글쓰기 | 2. 글조회 | 3. 로그아웃");
							System.out.print(">>> ");
							
							int select = 0;
							try {
								select = Integer.parseInt(sc.nextLine());
							} catch (NumberFormatException e) {
								System.out.println("숫자만 입력해주세요");
								continue;
							}
							
							if(select == 1) {
								// TODO 글쓰기
								System.out.println("글 제목을 입력해주세요.");
								System.out.print(">>> ");
								String title = sc.nextLine();
								System.out.println("글 내용을 입력해주세요.");
								System.out.print(">>> ");
								String content = sc.nextLine();

								BoardVO board = new BoardVO(0, title, content, login.getMemId(), sdf.format(new Date()));
								int count = boardService.writeBoard(board);
								
								if(count > 0) {
									System.out.println("글 쓰기가 완료되었습니다.");
								}else {
									System.out.println("글 작성 실패");
								}
								
							}else if(select == 2) {
								// TODO 글조회
								System.out.println("글 번호를 입력해 주세요");
								System.out.print(">>> ");
								
								int no = Integer.parseInt(sc.nextLine());
								
								BoardVO board = boardService.getBoard(no);
								
								if(board != null) {
									System.out.println("=========================");
									System.out.println("제목: " + board.getBoardTitle());
									System.out.println("작성자: " + board.getBoardAuthor());
									System.out.println("작성일: " + board.getBoardDate());
									System.out.println("내용: " + board.getBoardContent());
									System.out.println("=========================");
								}else {
									System.out.println("해당 글번호는 존재하지 않습니다.");
								}
								
							}else if(select == 3) {
								// 로그아웃
								break;
							}else {
								System.out.println("잘못 입력하셨습니다.");
							}
							
							
						}
						
						
					}else {
						// 로그인 실패
						System.out.println("비밀번호가 일치하지 않습니다.");
					}
				}else {
					System.out.println("존재하지 않는 아이디입니다.");
				}
			}else if(command == 3) {
				// 종료
				System.out.println("종료합니다.");
				break;
			}else {
				System.out.println("잘못 입력하셨습니다.");
			}
			
		}
		
		
	}

}
