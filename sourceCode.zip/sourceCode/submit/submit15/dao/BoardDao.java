package chanung.submit15.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import chanung.submit15.model.BoardVO;

public class BoardDao {
	
	private static BoardDao instance = new BoardDao();
	
	public static BoardDao getInstance() {
		if(instance == null) {
			instance = new BoardDao();
		}
		return instance;
	}
	
	private BoardDao() {
		
	}
	
	// 글 조회 (SELECT)
	public BoardVO getBoard(Connection conn, int no) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		  no				");
		query.append("		, board_title		");
		query.append("		, board_content		");
		query.append("		, board_author	 	");
		query.append("		, board_date	 	");
		query.append("FROM						");
		query.append("		boards				");
		query.append("WHERE 1=1					");
		query.append("  AND no = ?				");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setInt(idx++, no);
		
		ResultSet rs = ps.executeQuery();
		
		BoardVO result = new BoardVO();
		
		while(rs.next()) {
			result.setNo(rs.getInt("no"));
			result.setBoardTitle(rs.getString("board_title"));
			result.setBoardContent(rs.getString("board_content"));
			result.setBoardAuthor(rs.getString("board_author"));
			result.setBoardDate(rs.getString("board_date"));
		}
		
		if(rs != null) rs.close();
		if(ps != null) ps.close();
		
		return result;
	}
	
	
	// 게시글 목록 불러오기(SELECT)
	public ArrayList<BoardVO> getBoardList(Connection conn) throws SQLException{
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		  no				");
		query.append("		, board_title		");
		query.append("		, board_content		");
		query.append("		, board_author	 	");
		query.append("		, board_date	 	");
		query.append("FROM						");
		query.append("		boards				");
		query.append("ORDER BY no DESC			");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ResultSet rs = ps.executeQuery();
		ArrayList<BoardVO> result = new ArrayList<>();
		
		while(rs.next()) {
			BoardVO temp = new BoardVO();
			temp.setNo(rs.getInt("no"));
			temp.setBoardTitle(rs.getString("board_title"));
			temp.setBoardContent(rs.getString("board_content"));
			temp.setBoardAuthor(rs.getString("board_author"));
			temp.setBoardDate(rs.getString("board_date"));
			result.add(temp);
		}
		
		if(rs != null) rs.close();
		if(ps != null) ps.close();
		
		return result;
	}
	
	// 글쓰기 (INSERT)
	public int writeBoard(Connection conn, BoardVO board) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO							");
		query.append("		boards			  				");
		query.append("VALUES	(							");
		query.append("		board_seq.nextval				");
		query.append("		, ?								");
		query.append("		, ?								");
		query.append("		, ?								");
		query.append("		, ?								");
		query.append("		)								");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		int idx = 1;
		ps.setString(idx++, board.getBoardTitle());
		ps.setString(idx++, board.getBoardContent());
		ps.setString(idx++, board.getBoardAuthor());
		ps.setString(idx++, board.getBoardDate());
		
		int cnt = ps.executeUpdate();
		
		if(ps != null) ps.close();
		
		return cnt;
	}
	
	
	
}
