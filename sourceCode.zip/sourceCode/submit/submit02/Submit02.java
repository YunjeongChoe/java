package chanung.submit02;

import java.util.Scanner;

public class Submit02 {

	public static void main(String[] args) {
		// 사용자로부터 이름, 국어, 영어, 수학 점수를
		// 입력 받고 평균을 포함해서 콘솔창에 출력
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("이름을 입력해주세요.");
		System.out.print(">>> ");
		String name = sc.nextLine();
		
		System.out.println("국어 점수를 입력해주세요.");
		System.out.print(">>> ");
		int scoreKor = Integer.parseInt(sc.nextLine());
		System.out.println("영어 점수를 입력해주세요.");
		System.out.print(">>> ");
		int scoreEng = Integer.parseInt(sc.nextLine());
		System.out.println("수학 점수를 입력해주세요.");
		System.out.print(">>> ");
		int scoreMath = Integer.parseInt(sc.nextLine());
		
		double avg = (scoreKor + scoreEng + scoreMath) / 3.0;
		
		System.out.println("이름: " + name);
		System.out.println("국어: " + scoreKor);
		System.out.println("영어: " + scoreEng);
		System.out.println("수학: " + scoreMath);
		System.out.println("평균: " + avg);
		
		System.out.println("\n=======================\n");

		String idBack = "1231476";
		
		String first = idBack.substring(0, 1);
		int intFirst = Integer.parseInt(first);
		
		System.out.println(intFirst % 2);
		
		String gender = (intFirst % 2 == 1) ? "남" : "여";
		System.out.println(gender);
		
	}

}
