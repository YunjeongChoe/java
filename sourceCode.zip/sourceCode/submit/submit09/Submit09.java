package chanung.submit09;

import java.util.ArrayList;
import java.util.Collections;

public class Submit09 {

	public static void main(String[] args) {
		// Q. 01
		// 정수를 담을 수 있는 ArrayList 객체를
		// 생성
		ArrayList<Integer> intList = new ArrayList<Integer>();
		
		// 10부터 20 사이의 랜덤 숫자를 10개 담기
		// 0 ~ 10 + 10 => 10 ~ 20
		for(int i = 0; i < 10; i++) {
			int randInt = (int)(Math.random() * 11) + 10;
			intList.add(randInt);
		}
		
		// 한줄로 출력
		for(int i = 0; i < intList.size(); i++) {
			System.out.print(intList.get(i) + " ");
		}
		System.out.println();
		
		// 중복된 숫자를 제거
		// 1. 새로운 배열에 옮기기
		ArrayList<Integer> newList = new ArrayList<>();
		for(int i = 0; i < intList.size(); i++) {
			if(newList.indexOf(intList.get(i)) == -1) {
				newList.add(intList.get(i));
			}
		}
		for(int i = 0; i < newList.size(); i++) {
			System.out.print(newList.get(i) + " ");
		}
		System.out.println();
		
		// 2. 새로운 배열 없이 중복 제거
		for(int i = 0; i < intList.size()-1; i++) {
			// j를 뒤에서부터 앞으로 순회시킨다.
			for(int k = intList.size()-1; k > i ; k--) {
				if(intList.get(i) == intList.get(k)) {
					intList.remove(k);
				}
			}
		}
		for(int i = 0; i < intList.size(); i++) {
			System.out.print(intList.get(i) + " ");
		}
		System.out.println();
		
		// 오름차순 정렬 후 출력
		Collections.sort(intList);
		
		for(int i = 0; i < intList.size(); i++) {
			System.out.print(intList.get(i) + " ");
		}
		System.out.println();
		
		// 내림차순 정렬 후 출력
		// [단축키 Alt + Shift + R]
		// 변수명, 함수명 이름 한번에 바꾸기
		for(int k = 0; k < intList.size(); k++) {
			for(int i = 0; i < intList.size()-1-k; i++) {
				// i > i+1 하면 오름차순
				// i < i+1 하면 내림차순
				if(intList.get(i) < intList.get(i+1)) {	
					int tmp = intList.get(i);
					intList.set(i, intList.get(i+1));
					intList.set(i+1, tmp);
				}
			}
		}
		
		System.out.println("\n====================\n");
		
		// 아내가 사고 싶은 제품 [냉장고, 세탁기, 에어컨]
		ArrayList<String> wipeList = new ArrayList<String>();
		wipeList.add("냉장고");
		wipeList.add("로봇청소기");
		wipeList.add("세탁기");
		wipeList.add("에어컨");
		
		// 남편이 사고 싶은 제품 [노트북, TV, 에어컨]
		ArrayList<String> husList = new ArrayList<String>();
		husList.add("노트북");
		husList.add("로봇청소기");
		husList.add("TV");
		husList.add("에어컨");
		
		// 서로 사고 싶은 물건 목록(교집합)
		ArrayList<String> wantBuy = new ArrayList<>();
		for(int i = 0; i < wipeList.size(); i++) {
			if(husList.indexOf(wipeList.get(i)) != -1) {
				wantBuy.add(wipeList.get(i));
			}
		}
		System.out.println(wantBuy);
		
		// 교집합을 위한 .retainAll() 이용
		wantBuy = new ArrayList<>();
		wantBuy.addAll(wipeList);
		System.out.println(wantBuy);
		wantBuy.retainAll(husList);
		System.out.println(wantBuy);
		
		// 전체 구매 목록 (합집합)
		ArrayList<String> allBuy = new ArrayList<>();
		
		for(int i = 0; i < wipeList.size(); i++) {
			allBuy.add(wipeList.get(i));
		}
		for(String item : husList) {
			if(allBuy.indexOf(item) == -1) {
				allBuy.add(item);
			}
		}
		System.out.println(allBuy);
		
	}

}
