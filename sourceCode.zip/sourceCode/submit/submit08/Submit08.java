package chanung.submit08;

import java.util.Arrays;

public class Submit08 {
	
	public static void main(String[] args) {
		// Q. 01 로또 생성기
		int[] myLotto = makeLotto();
		printArray(myLotto);
		
		// 지난주 1등 당첨 번호
		int[] winLotto = {3, 4, 15, 23, 27, 45};
		
		int num = 0;
		while(true) {
			System.out.println((++num) + "회 실행");
			if(checkLotto(winLotto, makeLotto())) {
				System.out.println("1등 당첨!!");
				System.out.println("구매 횟수: " + num);
				System.out.println("구매 금액: " + (num*1000L));
				break;
			}
		}

		
	}// main 끝
	
	
	// 숫자 배열 두개를 입력(파라미터) 받아
	// 전부다 일치하는 경우
	// true를 리턴
	// 1개라도 틀리면 false를 리턴하는 함수
	static boolean checkLotto(int[] winArr, int[] myArr) {
		int count = 0;
		for(int i = 0; i < winArr.length; i++) {
			if(winArr[i] == myArr[i]) {
				count++;
			}
		}
//		if(count == 6) {
//			return true;
//		}
//		return false;
		return (count == 6);
	}
	
	
	static int[] makeLotto() {
		int[] lottoArray = new int[6];
		
		// 로또 번호 담기
		int idx = 0;
		while(idx < 6) {
			int randInt = (int)(Math.random()*45) + 1;
			boolean isDuple = false;
			// 중복체크 (중복되면 isDuple은 true)
			for(int i = 0; i < lottoArray.length; i++) {
				if(lottoArray[i] == randInt) {
					isDuple = true;
				}
			}
			if(isDuple == false) {
				lottoArray[idx] = randInt;
				idx++;
			}
		}
		
		// 로또 정렬
		// Q. 02 선택정렬
		for(int i = 0; i < lottoArray.length - 1; i++) {
			// 최댓값 구하기
			int maxVal = lottoArray[0];
			int maxIdx = 0;
			for(int j = 1; j < lottoArray.length - i; j++) {
				if(lottoArray[j] > maxVal) {
					maxVal = lottoArray[j];
					maxIdx = j;
				}
			}
			
			// maxVal에 최댓값이 담겨있다.
			// maxIdx에 최댓값의 인덱스가 담겨있다.
			
			// 자리 바꾸기
			int temp = lottoArray[maxIdx];
			lottoArray[maxIdx] = lottoArray[lottoArray.length-1-i];
			lottoArray[lottoArray.length-1-i] = temp;
			
			
		}
		
		return lottoArray;
	}
	
	
	
	
	static void printArray(int[] intArray) {
		for(int i = 0; i < intArray.length; i++) {
			if(i == intArray.length -1) {
				System.out.println(intArray[i]);
			}else {
				System.out.print(intArray[i] + ", ");
			}
		}
	}
	
	static void printArray(String[] strArray) {
		for(int i = 0; i < strArray.length; i++) {
			if(i == strArray.length -1) {
				System.out.println(strArray[i]);
			}else {
				System.out.print(strArray[i] + ", ");
			}
		}
	}
	
}
