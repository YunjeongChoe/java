package chanung.submit03;

import java.util.Scanner;

public class Submit03 {

	public static void main(String[] args) {
		// Q. 01 국어, 영어, 수학 점수를 입력받고
		// 평균을 출력한 다음, 등급까지 출력
		Scanner sc = new Scanner(System.in);
		
		System.out.print("국어 점수 입력: ");
		int kor = Integer.parseInt(sc.nextLine());
		System.out.print("영어 점수 입력: ");
		int eng = Integer.parseInt(sc.nextLine());
		System.out.print("수학 점수 입력: ");
		int math = Integer.parseInt(sc.nextLine());
		
		double doubleAvg = (kor + eng + math) / 3.0;
		System.out.println("평균: " + doubleAvg);

		// 실수 반올림
		long avg = Math.round(doubleAvg);
		System.out.println("반올림한 평균: " + avg);
		
		if(avg >= 90) {
			System.out.println("A 등급");
		}else if(avg >= 80) {
			System.out.println("B 등급");
		}else if(avg >= 70) {
			System.out.println("C 등급");
		}else {
			System.out.println("D 등급");
		}
		
		System.out.println("\n=======================\n");
		
		// 팩토리얼
		
		// 10!
		int facTen = 1;
		for(int i = 1; i <= 10; i++) {
			facTen *= i;
		}
		System.out.println(facTen);
		
		// 15!
		long facResult = 1;
		for(int i = 1; i <= 15; i++) {
			facResult *= i;
		}
		System.out.println(facResult);
		
		System.out.println("\n======================\n");
		
		// 월리를 찾아라
		
		String findWally = "윌리울리일리울리울리일리월리일리윌리월리울리일리일리월리일리윌리일리윌리일리월리월리윌리울리윌리울리일리울리울리윌리일리";
		
		int countWally = 0;
		for(int i = 0; i < findWally.length() - 1; i++) {
			String twoWord = findWally.substring(i, i+2);
			
			if(twoWord.equals("월리")) {
				countWally++;
			}
		}
		System.out.println("월리는 총 " + countWally);
		
		System.out.println("\n=======================\n");
		
		// 거꾸로 트리
		// *****
		// ****
		// ***
		// **
		// *
		
		String star = "*****";
		for(int i = 0; i < 5; i++) {
			System.out.println(star.substring(i));
		}
		
	}

}
