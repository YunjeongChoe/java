package chanung.submit06;

public class Submit06 {

	public static void main(String[] args) {
		// 명함 만들기
		// ================
		// 이름: 찬웅
		// 연락처: 000
		// 이메일 : 123@.com
		// ================
		makeCard("찬웅쌤", "010-7398-7332", "akow283@gmail.com");

		System.out.println("\n==========================\n");
		
		// n층 짜리 트리
		makeTree(9);
		
		System.out.println("\n=========================\n");
		
		// 십진수를 이진수(String 타입)으로 리턴해주는
		// makeBinary 함수
		
		String binaryString = Integer.toBinaryString(30);
		System.out.println(binaryString);
		System.out.println(makeBinary(30));
		
		String hexString = Integer.toHexString(23);
		System.out.println(hexString);
		

		
	} // main 끝
	
	static String reverse(String str) {
		// 로꾸꺼 (String을 뒤집는 녀석)
		String reverse = "";
		for(int i = str.length()-1; i >= 0; i--) {
			reverse += str.substring(i, i+1);
		}
		return reverse;
	}
	
	static String makeBinary(int num) {
		// 30이 들어왔다.
		// 30을 2로 나눠서 나머지 0 / 몫은 15
		// 15를 2로 나눠서 나머지 1 / 몫은 7
		// 7을 2로 나눠서 나머지 1 / 몫은 3
		// 3을 2로 나눠서 나머지 1 / 몫은 1
		
		String result = "";
		while(true) {
			result += num % 2;
			if(num == 1) {
				break;
			}
			num /= 2;
		}
		return reverse(result);
	}
	
	
	static void makeTree(int num) {
		String star = "*";
		for(int i = 0; i < num; i++) {
			String blank = "";
			for(int j = 0; j < num-1-i; j++) {
				blank += " ";
			}
			System.out.println((i+1) + ". " + blank + star);
			star += "**";
		}
	}
	
	static void makeCard(String name, String phone, String email) {
		System.out.println("==================");
		System.out.println("이름: " + name);
		System.out.println("연락처: " + phone);
		System.out.println("이메일: " + email);
		System.out.println("==================");
	}
	

}
