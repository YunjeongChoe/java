package chanung.submit04;

import java.util.Scanner;

public class Submit04 {

	public static void main(String[] args) {
		// 룰렛
		// 5834도 돌아갔다.
		// 그때의 바퀴수랑, 멈췄을때의 각도에 대한
		// 상품을 출력
		
		int rotateCount = 5834 / 360;
		System.out.println(rotateCount + "바퀴");
		int angle = 5834 % 360;
		if(angle <= 60) {
			System.out.println("사탕");
		}else if(angle <= 120) {
			System.out.println("초콜릿");
		}else if(angle <= 180) {
			System.out.println("쿠키");
		}else if(angle <= 240) {
			System.out.println("콜라");
		}else if(angle <= 300) {
			System.out.println("아이스크림");
		}else {
			System.out.println("커피");
		}
		
		System.out.println("\n======================\n");
		
		// 로꾸꺼
		Scanner sc = new Scanner(System.in);
		System.out.print("거꾸로 뒤집을 문자열 입력: ");
		String inputText = sc.nextLine();
		
		// 오늘은 수요일
		// length는 7
		// 인덱스는 0부터 시작이라 length-1 까지다.
		// charAt 이용
		for(int i = inputText.length()-1; i >= 0; i--) {
			System.out.print(inputText.charAt(i));
		}
		
		System.out.println();
		
		// substring 이용
		String reverse = "";
		for(int i = inputText.length()-1; i >= 0; i--) {
			reverse += inputText.substring(i, i+1);
		}
		System.out.println(reverse);
		
		System.out.println("\n=======================\n");
		
		// 크리스마스 트리
		//     *
		//    ***
		//   *****
		//  *******
		// *********
		
		// for문이 1, 2, 3, 4, 5번 실행
		// *은 1, 3, 5, 7, 9개
		// " "은 4, 3, 2, 1, 0개
		
		String star = "*";
		for(int i = 0; i < 5; i++) {
			String blank = "";
			for(int j = 0; j < 4-i; j++) {
				blank += " ";
			}
			System.out.println(blank + star);
			star += "**";
		}
		
		// 거꾸로 트리
		// *********
		//  *******
		//   *****
		//    ***
		//     *
		
		// for문이 1,2,3,4,5번 반복
		// *은 9,7,5,3,1
		// " "은 0,1,2,3,4
		
		String blank = "";
		for(int i = 0; i < 5; i++) {
			star = "*";
			for(int j = 0; j < 4-i; j++) {
				star += "**";
			}
			System.out.println(blank + star);
			blank += " ";
		}
		
		
		
		
		
		
		
		
		
	}

}
