package chanung.submit05;

import java.util.Scanner;

public class UpDown {

	public static void main(String[] args) {
		// 랜덤한 수 얻기
		System.out.println(Math.random());
		
		// Math.random() 은 0~1 사이의 랜덤 실수 리턴
		// Math.random() * 10은 0~10 사이의 랜덤 실수 
		// (int) (Math.random() * 10) 은 0~9 중 랜덤 정수
		// 1부터 50까지 중 랜덤한 정수를 얻고 싶다
		// (int) (Math.random() * 50) + 1
		// 0~50
		int randInt = (int) (Math.random() * 50) + 1;
		System.out.println(randInt);
		
		// TODO 반복문 (for문, while문)
		// 사용자로부터 숫자 입력 받음(int)
		// randInt 와 비교
		
		// 반복문 종료(break) 조건
		// 1. 정답을 맞춘 경우
		// 2. 5번 반복이 된 경우
		
		Scanner sc = new Scanner(System.in);
		int chance = 5;
		
		while(true) {
			System.out.print("숫자를 입력해주세요: ");
			int userPick = Integer.parseInt(sc.nextLine());
			
			if(userPick == randInt) {
				System.out.println("정답입니다.");
				break;
			}
			
			chance -= 1;
			if(chance <= 0) {
				System.out.println("실패하였습니다. 정답은 "
						+ randInt + "입니다.");
				break;
			}
			
			if(userPick < randInt) {
				System.out.println("업!! 기회가 " + chance 
						+ "번 남았습니다.");
			}else if(userPick > randInt) {
				System.out.println("다운!! 기회가 " + chance 
						+ "번 남았습니다.");
			}
			
		}
		
		
		for(int i = 4; i >= 0; i--) {
			System.out.print("숫자를 입력해주세요: ");
			int userPick = Integer.parseInt(sc.nextLine());
			
			if(userPick == randInt) {
				System.out.println("정답입니다.");
				break;
			}
			
			if(i <= 0) {
				System.out.println("실패하였습니다. 정답은 " + randInt + "입니다.");
				break;
			}
			
			if(userPick < randInt) {
				System.out.println("업!! 기회가 " + chance 
						+ "번 남았습니다.");
			}else if(userPick > randInt) {
				System.out.println("다운!! 기회가 " + chance 
						+ "번 남았습니다.");
			}
		}
		
		
		
		
		
				
				
				
				
				
		
		
		
	}

}
