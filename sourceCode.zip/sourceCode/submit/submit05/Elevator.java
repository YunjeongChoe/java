package chanung.submit05;

import java.util.Scanner;

public class Elevator {

	public static void main(String[] args) {

		int elevatorA = 10;	// 엘리베이터 A의 위치
		int elevatorB = 4;	// 엘리베이터 B의 위치
		
		// TODO 사용자의 위치를 입력 받고
		// 사용자의 위치와 각 엘리베이터의 층수
		// 차이를 계산
		// 해당 층수 차이에 따른 엘리베이터 이동
		// (층수 차이가 적은게 이동, 층수 차이가
		// 같다면, 높은 층에 있는 엘리베이터가 이동)
		
		Scanner sc = new Scanner(System.in);
		final int ACTIVE_ELEVATOR_A = 200;
		final int ACTIVE_ELEVATOR_B = 201;
		
		final String START_ELEVATOR = "===== 희영빌딩 엘리베이터 =====";
		
		int state = 0;
		
		while(true) {
			System.out.println(START_ELEVATOR);
			System.out.println("승강기 A의 현재 위치: " + elevatorA);
			System.out.println("승강기 B의 현재 위치: " + elevatorB);
			System.out.print("몇층에 가시나요?[종료는 q 또는 exit]: ");
			
			String inputText = sc.nextLine();
			
			if(inputText.toLowerCase().equals("q") 
					|| inputText.equalsIgnoreCase("exit")) {
				System.out.println("프로그램이 종료되었습니다.");
				break;
			}
			
			int floor = Integer.parseInt(inputText);
			System.out.println(floor + "층에서 엘리베이터 호출");
			
			// 사용자의 위치와 각 엘리베이터 층수 차이 계산
			int diffA = Math.abs(floor - elevatorA);
			int diffB = (floor > elevatorB) 
					? (floor - elevatorB) : (elevatorB - floor);
			
			if(diffA > diffB) {
				System.out.println("승강기 B가 " + floor + "층으로 이동하였습니다.");
				state = ACTIVE_ELEVATOR_B;
			}else if(diffA < diffB) {
				System.out.println("승강기 A가 " + floor + "층으로 이동하였습니다.");
				state = ACTIVE_ELEVATOR_A;
			}else {
				if(elevatorA > elevatorB) {
					System.out.println("승강기 A가 " + floor + "층으로 이동하였습니다.");
					state = ACTIVE_ELEVATOR_A;
				}else {
					System.out.println("승강기 B가 " + floor + "층으로 이동하였습니다.");
					state = ACTIVE_ELEVATOR_B;
				}
			}
			
			// 호출한 엘리베이터 체크 후
			// 해당 엘리베이터를 이동시키기
			System.out.print("어느 층으로 이동하시겠습니까?: ");
			int goToFloor = Integer.parseInt(sc.nextLine());
			
			if(state == ACTIVE_ELEVATOR_A) {
				System.out.println("승강기 A가 " + goToFloor + "층으로 이동하였습니다.");
				elevatorA = goToFloor;
			}else {
				System.out.println("승강기 B가 " + goToFloor + "층으로 이동하였습니다.");
				elevatorB = goToFloor;
			}
			
			
		}
		
		
		
		
	}

}
