package game.racing;

import java.util.ArrayList;
import java.util.Scanner;

public class RacingMain {

	public static void main(String[] args) {
		ArrayList<Team> teamList = new ArrayList<>();
		
		teamList.add(new Team("1팀", 1000, 0, 0));
		teamList.add(new Team("2팀", 1000, 0, 0));
		teamList.add(new Team("3팀", 1000, 0, 0));
		
		Scanner sc = new Scanner(System.in);
		
		for(int i = 0; i < 5; i++) {
			String lane1 = "1. ";
			String lane2 = "2. ";
			String lane3 = "3. ";
			String lane4 = "4. ";
			
			System.out.println();
			
			for(Team t : teamList) {
				System.out.print(t.name + " 몇 레인에 배팅하시겠습니까? : ");
				int lane = Integer.parseInt(sc.nextLine());
				t.lane = lane;
				
				System.out.print("배팅 금액을 입력해주세요 " + "(소지금: " + t.money + ") : ");
				int bet = Integer.parseInt(sc.nextLine());
				t.bet = bet;
				
				t.money -= bet;
			}

			while(true) {
				int random = (int)(Math.random() * 8);
				
				// 8분의 1 확률로 한칸 전진
				if(random == 1) {
					lane1 += "=";
				}else if(random == 2) {
					lane2 += "=";
				}else if(random == 3) {
					lane3 += "=";
				}else if(random == 4) {
					lane4 += "=";
				}
				
				// 콘솔창에 공백 20줄 입력으로 기존 텍스트 안보이게
				for(int j = 0; j < 20; j++) {
					System.out.println();
				}
				
				// 각 말들의 진행 상황 출력
				System.out.println(lane1);
				System.out.println(lane2);
				System.out.println(lane3);
				System.out.println(lane4);
				
				if(lane1.length() == 40) {
					System.out.println("\n첫 번째 말 승리!!");
					betResult(1, teamList);
					break;
				}
				
				if(lane2.length() == 40) {
					System.out.println("\n두 번째 말 승리!!");
					betResult(2, teamList);
					break;
				}
				
				if(lane3.length() == 40) {
					System.out.println("\n세 번째 말 승리!!");
					betResult(3, teamList);
					break;
				}
				
				if(lane4.length() == 40) {
					System.out.println("\n네 번째 말 승리!!");
					betResult(4, teamList);
					break;
				}
				
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		System.out.println("게임 결과");
		for(Team t : teamList) {
			System.out.println(t.name + ": " + t.money);
		}
		
	}
	
	static void betResult(int lane, ArrayList<Team> teamList) {
		for(Team t : teamList) {
			if(t.lane == lane) {
				System.out.println(t.name + " " + (t.bet * 4) + "원 획득");
				t.money += t.bet * 4;
			}
		}
	}

}
