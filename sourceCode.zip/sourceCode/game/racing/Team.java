package game.racing;

public class Team {
	String name;	// 팀명
	int money;		// 소지금
	int lane;		// 배팅한 말 번호
	int bet;		// 배팅 금액
	
	public Team(String name, int money, int lane, int bet) {
		this.name = name;
		this.money = money;
		this.lane = lane;
		this.bet = bet;
	}
	
}
