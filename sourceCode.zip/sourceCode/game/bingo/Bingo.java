package game.bingo;

public class Bingo {
	String front = "[]";
	int num;
	
	Bingo(int num){
		this.num = num;
	}
}
