package game.fishing;

import java.util.ArrayList;

public class Fisher {
	String name;
	ArrayList<Fish> bag = new ArrayList<Fish>();
	
	public Fisher(String name) {
		this.name = name;
	}
}
