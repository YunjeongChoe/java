package Review;

public class Review04 {

	public static void main(String[] args) {
		
		
		int[] scores;
		scores = new int[] {83, 90, 87};
		int sum1 = 0;
		for(int i = 0; i < scores.length; i++) {
			sum1 += scores[i];
		}
		System.out.println("sum1 : " + sum1);
		
		
		int sum2 = add(new int[] {83, 90, 87} ) ;
		System.out.println("sum2 : " + sum2);
		
		
		
		System.out.println("\n-----------------------로또 번호 만들기----------------------------\n");
		int[] intArray = new int[6];
		
		for(int i = 0; i < intArray.length; i++) {
			int randInt = (int)(Math.random()* 45) + 1;
			intArray[i] = randInt;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

	private static int add(int[] scores) {
		int sum = 0;
		for(int i = 0; i < scores.length; i ++) {
			sum += scores[i];
		}
		return sum;
	}

}
