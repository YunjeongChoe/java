package Review;

import java.util.Scanner;

public class Review03 {

	public static void main(String[] args) {
		
		
		//콘솔창에 1부터 10까지 출력하시오
		for(int i = 0; i < 11; i++) {
			System.out.println(i);
		}
		
		
		System.out.println("\n---------------1부터 20까지 더하기------------------\n");
		
		int result = 0;
		for(int i = 1; i <=20; i++) {
			result += i;
		}
		System.out.println(result);

		
		System.out.println("\n-----------------구구단 2단-------------------\n");
		
		for(int i=1; i <= 9; i++) {
			System.out.println("2 x " + i + " = " + (i*2));
		}
		
		
		
		
		System.out.println("\n---------------1부터 10까지 홀수만 출력---------------\n");
		
		for(int i=1; i < 10; i ++) {
			if(i % 2 == 1) {
			System.out.println(i);
			}
		}
		
		
		
		System.out.println("\n-----------------for문으로 5층 트리 만들기------------------------\n");
		//아래의 5층 트리를 for문을 사용하여 만들어주세요
//		System.out.println("*");
//		System.out.println("**");
//		System.out.println("***");
//		System.out.println("****");
//		System.out.println("*****");
		String star = "";
		for(int i = 0; i < 5; i++) {
			star += "*";
		System.out.println(star);
		}
		
		
		
		
		
		System.out.println("\n------------------10부터 1까지 출력--------------------\n");
		
		int num = 10;
		for(int i = 0; i < 10; i++) {
			System.out.println(num--);
		}
		
		
		
		
		System.out.println("\n-------------------거꾸로 구구단 2단--------------------\n");
		
		for(int i = 9; i > 0; i--) {
			System.out.println("2 x " + i + " = " + (i*2));
		}
		
		
		
		
		System.out.println("\n-----------------각 자릿수의 합------------------\n");
		String example = "75426245324";
		int results = 0;
		for(int i=0; i < example.length(); i++) {
			results += Integer.parseInt(example.substring(i, i+1));
		}
		System.out.println(results);
		
		
		
		
		
		System.out.println("\n-------------------슈의 갯수-------------------------\n");
		String syusyu = "슈슈슈ㅠ슈ㅠㅅ슛슈슈ㅠ슈ㅠ슈ㅠㅠㅅ슛슛슈";
		int numOne = 0;
		for(int i=0; i < syusyu.length(); i++) {
			String str = syusyu.substring(i, i+1);
			if(str.equals("슈")) {
				numOne ++;
			}
		}
		System.out.println(numOne);
		
		
		
		
		System.out.println("\n------------------2중 for문으로 구구단 출력-----------------------\n");

		//2 X 2 = 4
		//   :
		//2 X 9 = 18
		//3 X 2 = 6
		//   :
		//3 X 9 = 27  9단까지
		for(int i = 2; i <= 9; i++) {
			for(int j = 2; j <=9; j++) {
				System.out.println(i + " x " + j + " = " + (i*j));
			}
		}
		
		
		
		System.out.println("\n--------------------------트리 만들기---------------------\n");

				//    *
				//   **
				//  ***
				// ****
				//*****
		
		String stars = "";
		String blanks = "     ";
		for(int i = 0; i <+5; i++) {
			stars += "*";
		System.out.println(blanks.substring(i) + stars);
			
		}
		
		System.out.println("\n---------------------이중 for문으로 트리만들기--------------------------\n");

				//외부 for문이 한번 돌 때 *은 1개, 내부 for문에 의해 " "은 5개
				//외부 for문이 한번 돌 때 *은 2개, 내부 for문에 의해 " "은 4개
		
		String starTree = "";
		for(int i=0; i < 5; i++) {
			starTree += "*";
			String blanked = "";
			for(int j=0; j < 5 - i; j++) {
				blanked += " ";
			}
			System.out.println(blanked + starTree);
		}
		
		
		
		
		System.out.println("\n------------\n");
		String star1 = "*****";
		for(int i = 5; i > 0; i--) {
			star1 = star1.substring(0, i);
			System.out.println(star1);
			;
		}
		
		System.out.println("\n------------\n");
		
		String star2 = "*****";
		for(int i = 5; i > 0; i--) {
			star2 = star2.substring(0, i);
			String blank2 = "";
			for(int j = 0; j < 5 - i; j++) {
				blank2 += " ";
			}
			System.out.println(star2 + blank2);
		}
		
		
		
		String findWally = "윌리울리일리울리울리일리월리일리윌리월리울리일리일리월리일리윌리일리윌리일리월리월리윌리울리윌리울리일리울리울리윌리일리";
		
		int count = 0;
		for(int i = 0; i < (findWally.length()); i +=2) {
			String str3 = findWally.substring(i, i +2);
			String name = "월리";
			if(str3.equals(name)) {
				count ++;
			}
		}
		System.out.println(count);
		
		
		
		
		
		
		System.out.println("\n---------------------while문으로 1부터 100까지 합-----------------------\n");
		int sum = 0;
		int k = 1;
		while (k <= 100) {
			sum += k;
			k++;
		}
		System.out.println(sum);
		
		
		
		
		
		System.out.println("\n--------------------for문으로 1부터 100까지 합----------------------\n");
		int int1 = 0;
		for(int h=1; h <=100; h++) {
			int1 += h;
		}
		System.out.println(int1);
		
		
		
		
		
		System.out.println("\n--------------------업다운 게임 풀이----------------------\n");
		int randInt = 0;
		//while문 
				
		Scanner sc = new Scanner(System.in);
		
		int randInt1 = (int) (Math.random() * 50) + 1;
		
		int chance = 5;
		
		while(true){
			System.out.println("숫자를 입력해주세요: ");
			int userPick = Integer.parseInt(sc.nextLine());
			
			if(userPick == randInt1) {
				System.out.println("정답입니다. ");
				break;
			}
			
			chance -= 1;
			if(chance <=0) {
				System.out.println("실패하였습니다. 정답은" + randInt1 + "입니다");
				break;
			}
			
			if(userPick < randInt1) {
				System.out.println("업!! 기회가 " + chance + "번 남았습니다.");
			}else if(userPick > randInt1) {
				System.out.println("다운!! 기회가 " + chance + "번 남았습니다.");
			}
		}
		
		
		//for문
		for(int i = 4; i >= 0; i--) {
			System.out.println("숫자를 입력해주세요: ");
			int userPick = Integer.parseInt(sc.nextLine());
			
			if(userPick == randInt) {
				System.out.println("정답입니다");
				break;
			}
			
			if(i <= 0) {
				System.out.println("실패하였습니다. 정답");
			}if(userPick < randInt1) {
				System.out.println("업!! 기회가 " + chance + "번 남았습니다.");
			}else if(userPick > randInt1) {
				System.out.println("다운!! 기회가 " + chance + "번 남았습니다.");
			}
		
		
		
			System.out.println("\n--------------------엘리베이터 ----------------------\n");
		
			
			int elevatorA = 10;
			int elevatorB = 4;
			
			while(true) {
				System.out.println("======희영 엘리베이터=====");
				System.out.println("승강기 A의 현재 위치: " + elevatorA);
				System.out.println("승강기 B의 현재 위치: " + elevatorB);
				System.out.print("몇 층에 가시나요? 종료 q");
				
				String inputText = sc.nextLine();
				
				if(inputText.toLowerCase().equals("q")||inputText.equalsIgnoreCase("exit"))
				break;
			
			
		int floor = Integer.parseInt(inputText);
		System.out.println(floor + "층에서 엘리베이터를 호출합니다.");
		//사용자의 위치와 각 엘리베이터 층수 차이를 계산하기 위해
		int diffA = Math.abs(floor - elevatorA);
		int diffB = (floor > elevatorB) ? (floor - elevatorB) : (elevatorB - floor);
		
//		int diffB = floor - elevatorB;
//		
//		if(diffB < 0) {
//			diffB *= -1;
//		}
		
		if(diffA > diffB) {
			System.out.println("승강기 B가 " + floor + "층으로 이동하였습니다.");
			elevatorB = floor;
		}else if(diffA < diffB) {
			System.out.println("승강기 A가 " + floor + "층으로 이동하였습니다.");
			elevatorA = floor;
		}else {
			if(elevatorA > elevatorB) {
				System.out.println("승강기 A가 " + floor + "층으로 이동하였습니다.");
				elevatorA = floor;
			}else {System.out.println("승강기 B가 " + floor + "층으로 이동하였습니다.");
			elevatorB = floor;
			}
		}
	}
		}	
		
		
		
		
		
		

	}
}
