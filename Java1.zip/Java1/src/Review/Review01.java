package Review;

import java.util.Scanner;

public class Review01 {

	public static void main(String[] args) {
		
		
		//syso를 이용해 변수 출력
		System.out.println("이름: " + "최윤정");
		System.out.println("나이: " + 28);
		System.out.println("이메일: " + "gkfnekf12@gmail.com");
		
		System.out.println("\n===================================\n");
		
		
		//문자열 변수 
		//(.replace를 이용해 글자를 공백으로 바꾼 후 syso로 출력)
		String enigma = "너오구늘리뭐너먹구지리";
		
		String eni1 = enigma.replace("너", "");
		System.out.println("1차 암호 해독[너 제거]: " + eni1);
		String eni2 = eni1.replace("구", "");
		System.out.println("2차 암호 해독[구 제거]: " + eni2);
		String eni3 = eni2.replace("리", "");
		System.out.println("3차 암호 해독[리 제거]: " + eni3);
		System.out.println("해독완료!! ->" + eni3);
		
		
		System.out.println("\n===================================\n");
		
		
		//숫자형 문자열
		/* substring을 이용해 문자를 시작 인덱스/끝 인덱스 자른 뒤, 숫자 문자열을 숫자(정수)로 
		 * 바꿔주는 .Integer.parseInt를 이용 */
		String example = "418";
		
		String str1 = example.substring(0, 1);
		String str2 = example.substring(1, 2);
		String str3 = example.substring(2, 3);
		
		int int1 = Integer.parseInt(str1);
		int int2 = Integer.parseInt(str2);
		int int3 = Integer.parseInt(str3);
		
		int result = int1 + int2 + int3;
		
		System.out.println("결과는 : " + result );
		
		
		
		System.out.println("\n===================================\n");
		
		
		Scanner scn = new Scanner(System.in);
		System.out.println("이름을 입력해주세요:");
		
		
		
		
		
		
		System.out.println("\n===================================\n");
		
		//삼항 연산자
		//주민번호 뒷자리의 첫번째 숫자에 대한 성별을
		//“남”, “여” 문자열로 변수에 담아 콘솔창에 출력해보세요.
		//(주민번호 뒷자리의 첫번째 숫자가 홀수면 남성, 짝수면 여성)
		/* .substring을 사용하 앞글자를 자른뒤
		 * .Integer.parseInt를 사용하여 숫자형 문자열을 정수로 바꿔준 후,
		 * ("">"") ? "" : ""
		 * */
		String idBack = "3234567";
		
		String first = idBack.substring(0, 1);
		int intfirst = Integer.parseInt(first);
		
		
		String gender = (intfirst % 2 == 1) ? "남성" : "여성";
		
		System.out.println(gender);
		
		
		
	
		
		
		
		
		
		
		
		
		
		

	}

}
