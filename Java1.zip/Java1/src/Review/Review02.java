package Review;

public class Review02 {

	public static void main(String[] args) {
		
		
		int int1 = 100;
		
		int1++;
		System.out.println(int1);
		int1--;
		System.out.println(int1);
		
		int numFirst = 10;
		int numSecond = 3;
		
		numFirst = numFirst + 1;
		System.out.println(numFirst);               //11
		numFirst = numFirst + 2;
		System.out.println(numFirst);               //13
		
		System.out.println("\n=======================\n");
		
		
		
		//score가 90점 보다 크면 grade는 A, 80점 보다 크면 B, 나머지는 C
		int score = 85;
		String grade = (score > 90) ? "A" : ((score > 80) ? "B" : "C" );
		System.out.println(grade);
		
		int num = 340;
		String ver = (num > 400) ? "합격" : ((num >=350) ? "재시험" : "불합격");
		System.out.println(ver);
		
		
		//name이 empty면 안되고 phone이 10자리 또는 11자리, age가 14이상 이여야 함
		// || 좌우 조건 중 하나라도 참이라면 true, 둘다 참이여도 true, 둘다 거짓이면 false 리턴
		//&& 좌우 조건이 전부 참이여야만 true를 리턴함. 둘 중 하나라도 거짓이면 false를 리턴
		String name = "hhh";
		String phone = "01034898890";
		int age = 28;
		
		boolean chkname = name.length() > 0;
		boolean chkphone = phone.length() == 10 || phone.length() ==11;
		boolean chkage = age >= 14;
		
		System.out.println(chkname && chkphone && chkage);
		
		//!는 boolean의 값을 뒤집음 
		chkname = name.isEmpty();
		System.out.println(chkname);  // false
		chkname = !name.isEmpty();
		System.out.println(chkname);  //true
		
		
		System.out.println("\n==================================\n");
		
		//콘솔창에 1부터 10까지 출력하시오
		for(int i = 1; i < 11; i++) {
			System.out.println(i);
		}
		System.out.println("\n==================================\n");
		for(int i = 0; i < 20; i +=4) {
			System.out.println(i);
		}
		System.out.println("\n==================================\n");
		
		
		
		//1부터 20까지 더하기
		int sum = 0;
		for(int i = 1; i <21; i++) {
			sum += i;
		}
		System.out.println(sum);
		
		System.out.println("\n==================================\n");
		// 2단 구구단
		for(int i = 1; i < 10; i ++) {
			System.out.println("2 X " + i + " = " + (i*2));
		}
		
		System.out.println("\n==================================\n");
		//홀수만 뽑기
		for(int i = 1; i < 10; i ++) {
			if(i % 2 == 1) {
			System.out.println(i);
			}
		}
		

		
		
		

	}

}
