package ch12_exception;

public class ErrConstants {
	//API_0001 : 사용자가 문자열을 입력하지 않음(empty)
	public static final String API_0001 = "API_0001"; 
	//API_0001 : 사용자가 숫자를 입력함
	public static final String API_0002 = "API_0002"; 
}
