package ch05_control;

public class LoopFor {

	public static void main(String[] args) {
		
		
		System.out.println("\n=====================반복문=======================\n");
		//for문
		//콘솔창에 1부터 10까지 출력하시오
		for(int i = 1; i  <=10; i++) { //++ -> 1씩 커지는거 
		System.out.println(i);         //i를 계속 쓸 수 있는 이유:중괄호 안에서 끝났기 때문에 더이상 메모리가 남지 않음 
		}
		
		for(int i = 0; i < 10; i +=2) {  //i = i + 2
			System.out.println(i);
		}
		
		
		
		System.out.println("\n===================================\n");
		//1부터 20까지 더하기
		int addResult = 0;
		for(int i = 1; i <= 20; i++) {
			addResult += i;
		}
		System.out.println(addResult);
		
		
		//21부터 45까지
		int result = 0;
		for(int i = 21; i <46; i ++) {
			result += i;
		}
		System.out.println(result);
		
		
		
		
		
		
		
		System.out.println("\n===================================\n");
		
		for(double i = 0; i < 2; i += 0.2) {
			System.out.println(i);
			//실수인 float과 double의 연산은 부정확하므로 비추천 
		}
		
		for(int i = 0; i <= 20; i += 2) {
			System.out.println(i/10.0);
		}
		
		
		
		
		System.out.println("\n===================================\n");
		
		//구구단 2단
		//2 X 1 = 2
		//2 X 2 = 4
		//   :
		//2 X 9 = 18
		
		for(int i = 1; i < 9; i ++) {
			System.out.println("2 X " + i + " = " + (i*2));
		}
		
		
		/*
		 * 디버깅 모드 
		 * 코드라인 좌측 부분을 더블클릭하여 breakpoint(초록점)를 만든 후 실행
		 * [단축키: Ctrl + Shift + B]
		 * 토글형식이라 더블클릭 혹은 단축키로 생성/삭제 가능
		 * 
		 * 디버깅 목적
		 * 코드를 한 줄씩 실행해보며 변수에 어떤 값이 담기고 있는지 확인할 때 사용 
		 * 
		 * 디버깅 실행
		 * 상단 벌레모양의 아이콘 클릭{단축키: F11]
		 * 디버깅 모드에 적합한 화면(Perspective) 전환 여부
		 * 코드들이 위에서부터 실행되다가 breakpoint가 있는 지점에 멈춰서 대기를 한다.
		 * 
		 * 이후 상단의 Run - Step Over {단축키: F6]를 실행하면 한 줄씩 실행이 된다
		 * 
		 * 디버깅 모드 실행 중 종료하려면 Terminate 단축키 [Ctrl + F2]
		 * 
		 * 이후 원래 화면(Perspective)으로 돌아오려면 우측 상단에서 Java Perspective 클릭
		 * 
		 * 
		 * */
		
		
		System.out.println("\n==========================================\n");
		//1부터 10까지 홀수만 출력
		for(int i = 1; i < 10; i++) {
			if(i % 2 == 1) {
				System.out.println(i);
			}
		} //for문이 10번 실행됨
		
		for(int i = 1; i < 10; i +=2) {
			System.out.println(i);
		} //5번 실행 (성능 증가 = 프로그램 실행 속도가 증가)
		
		
		
		
		System.out.println("\n==========================================\n");
		//아래의 5층 트리를 for문을 사용하여 만들어주세요
		System.out.println("*");
		System.out.println("**");
		System.out.println("***");
		System.out.println("****");
		System.out.println("*****");
		
		
		String star = "";
		for(int i = 0; i < 10; i++) {
			star += "*";
			System.out.println(star);
		}
		
		
		
		
		System.out.println("\n==========================================\n");
		// %나머지 연산 주로 사용 예시
		//for문 내에서 순환하는 숫자에 대해서 사용
		
		//국수공장에서 면을 20cm 뽑고 있는데 5cm마다 잘라준다고 할 때
		for(int i = 0; i <20; i++) {
			System.out.println("||||||||||");
			//i가 4일때 면이 5cm가 돼서 잘라야 함
//			if(i==4) {
//				System.out.println("----------");
			//i가 9일때, i가 14일때 잘라야함
			if((i == 4) || (i == 9) || (i==14)) {
				System.out.println("----------");
			}
		}
		
		
		
		
		System.out.println("\n====================안성탕면======================\n");
		
		//라면 공장에서 면을 30cm 뽑고 있는데 6cm마다 잘라줘야 할 때
		for(int i=0; i<30; i++) {
			if(i % 2 ==1) {
				System.out.println("//////////");
			}else {
				System.out.println("\\\\\\\\\\\\\\\\\\\\");
			}
		
		//i가 5일때, 11일때, 17일때, 23일때 잘라야함
		
//		if(i % 6 == 5) {
//			System.out.println("----------");
		}
		
	
//		try {
//			Thread.sleep(300);
//			//현재 코드를 실행중 스레드를 괄호 안 시간 (단위:밀리초, ms)
//			//만큼 잠깐 재웠다가 깨어난다.
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		} 
		
		
		System.out.println("\n===================지금으로부터 100시간 후 몇 일 몇 시가 될까?=======================\n");

		int currentDay = 18;
		int currentHour = 9;
		for(int i = 0; i < 100; i++) {
			int day = currentDay + (currentHour/24);  //24나눈 몫이 day
			int hour = currentHour % 24;  //24로 나눴을때 나머지가
			System.out.println(day + "일 " + hour + "시");
			currentHour++;  //한시간씩 증가
			
		}
		
		System.out.println("\n=================거꾸로 for문=10부터 1까지 출력========================\n");

		int num = 10;
		for(int i = 0; i < 10; i++) {
			System.out.println(num--);
//			num--;
		}
		
		for(int i = 10; i >0; i--) {
			System.out.println(i);
		}
		
		
		
		
		System.out.println("\n===================//거꾸로 구구단 2단=======================\n");

		for(int i = 9; i > 0; i--) { 
			System.out.println("2 X " + i + " = " + i*2);  
		}
		
		
		
		System.out.println("\n==========================================\n");
		//for문으로 String문자열을 가지고 놀기
		//for문을 이용해서 숫자 문자열의 각 자리수를 더해서 결과를 출력 
		String example = "75426245324";
		int rslt = 0;
		for(int i = 0; i < (example.length()); i++) {
//			String str = example.substring(i, i+1);
//			int strInt = Integer.parseInt(str);
//			rslt += strInt;
			
			rslt += Integer.parseInt(example.substring(i, i+1));
			
		}
//		System.out.println("각 자리수를 더한 결과: " + rslt);
		
		
		
		System.out.println("\n==========================================\n");
		//슈의 갯수
		String syusyu = "슈슈슈ㅠ슈ㅠㅅ슛슈슈ㅠ슈ㅠ슈ㅠㅠㅅ슛슛슈";
		//syusyu 문자열의 길이만큼 반목하는 for문
		//반복문이 실행될때마다 syusyu를 한글자씩 자른다.
		//자른 글자가 슈인지 판별(if)
		//슈라면 count를 1씩 올려준다.
//		int count = 0;
//		for(int i=0; i < (syusyu.length()); i++) {
//			String str1 = syusyu.substring(i, i+1);
//			String str2 = "슈";
//			if(str1.equals(str2)) {
//				
//			
//			}
//		}
		int count = 0;
		for(int i=0; i < (syusyu.length()); i++) {
			String str1 = syusyu.substring(i, i+1);
			if(str1.equals("슈")) {
				count ++;
			}
		}
		System.out.println("슈의 갯수는: " + count);
		
		
		
		System.out.println("\n==========================================\n");
		
		//break문
		//i가 1부터 10까지 증가하는 for문에서 i가 5보다 커지게 되면 for문을 종료할 때
		for(int i = 1; i <= 10; i++) {
			if(i > 5) {
				break; //컴퓨터가 break명령어를 실행하면 가까운 반복문(for, while) 하나를 즉시 종료한다.
			}
			System.out.println(i);
		}
		
		//1부터 n까지 더한다고 했을 때, 100이상이 되는 n을 구하려고 할 때
		int sum = 0;
		for(int i =1; i < 9999; i ++) {
			sum +=i;
			
			if(sum >= 100) {
				System.out.println("100이상이 되는 n은? :" + i + "입니다.");
				break;
			}
		}
		
		
		System.out.println("\n==========================================\n");
		//continue문
		//구구단 7단을 출력하는데, 2,3,4 출력 안할 때
		for(int i = 2; i <=9; i++) {
			if(i < 5) {
				continue;   //컴퓨터가 실행 시 continue 아래 코드는 무시하고 바로 다음 for문으로 진행한다.
			}
			System.out.println("7 X " + i + " = " + (7*i));
		}
		
		
		
		
		System.out.println("\n==========================================\n");
		//이중 for문
		//구구단 출력
		//2 X 2 = 4
		//   :
		//2 X 9 = 18
		//3 X 2 = 6
		//   :
		//3 X 9 = 27  9단까지
		
		for(int i = 2; i <=9; i++) {
			for(int j =2; j <=9; j++) {
				System.out.println(i + " x "  + j  + " = " + (i*j));
			}
			
		}
		
		System.out.println("\n==========================================\n");
		
		//트리
		//    *
		//   **
		//  ***
		// ****
		//*****
		String blank = "    ";
		String starTree = "";
		for(int i = 0; i < 5; i++) {
			starTree += "*";
			System.out.println(blank.substring(i) + starTree);
		}
		
		//이중 for문으로 트리만들기
		//외부 for문이 한번 돌 때 *은 1개, 내부 for문에 의해 " "은 5개
		//외부 for문이 한번 돌 때 *은 2개, 내부 for문에 의해 " "은 4개
		
		String sTree = "";
		
		for(int i = 0; i < 5; i++) {
				sTree += "*";
				String blnk = "";
				for(int j = 0; j < 5 - i; j++) {
					blnk +=" ";
				}
				System.out.println(blnk + sTree);
			}
		}
	
	
	
	
	
		

	}

	

