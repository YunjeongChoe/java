package ch13_thread;

public class MakeString {

	public static void main(String[] args) {
		
		//문자열을 아주 길게 만들기
		
		String str = "";
		StringBuffer strBuff = new StringBuffer();
		StringBuilder strBuild = new StringBuilder();
		
		
		for(int i = 0; i < 100000000; i ++) {
//			str += (int)(Math.random()*10);
			strBuff.append((int)(Math.random()*10));
			if( i % 10000000 == 0) {
				System.out.println(i + "...");
			}
		}
		System.out.println(strBuild.length());
		
		
		
		
		
		Thread sulli = new Thread(()-> {
			int num = 600;
			for(int i = 0; i < 500000000; i ++) {
//				str += (int)(Math.random()*10);
				strBuff.append((int)(Math.random()*10));
				if( i % 10000000 == 0) {
					System.out.println(i + "...");
				}
			}
			System.out.println(strBuff.length());
		});
		sulli.start();
		
		
		
		
		
		
		
		Thread sungbin = new Thread(()-> {
			int num = 600;
			for(int i = 0; i < 500000000; i ++) {
//				str += (int)(Math.random()*10);
				strBuild.append((int)(Math.random()*10));
				if( i % 10000000 == 0) {
					System.out.println(i + "...");
				}
			}
			System.out.println(strBuild.length());
		});
		sungbin.start();
		
		
		
		
		
	}

}
