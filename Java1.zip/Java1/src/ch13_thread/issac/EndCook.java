package ch13_thread.issac;

//콜백함수를 위한 인터페이스
public interface EndCook {
	//콜백함수로 사용 할 추상 메소드
	public void endOfCook();
	
	
}
