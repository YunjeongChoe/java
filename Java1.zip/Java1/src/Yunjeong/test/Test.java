package Yunjeong.test;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("커맨드 입력");
			System.out.println("1. 안녕 출력 | 2. 바보 출력 | 3. 종료");
			System.out.print(">>> ");

			int command = Integer.parseInt(sc.nextLine());

			if (command == 1) {
				System.out.println("안녕");

			} else if (command == 2) {
				System.out.println("바보");
			} else if (command == 3) {
				break;
			} else {
				System.out.println("다시");
			}

		}

	}
}
