package Yunjeong.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class RoundTest {

	@Test
	public void testRound() {
		double result = JunitTest.round(3.141592, 3);
		assertEquals(3.141, result, 0.001);
		
	}

}
