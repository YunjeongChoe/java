package Yunjeong.test;

public class JunitTest {
	
	//입력한 실수(douNum)을 소수 n번째 자리로 반올림하여 리턴해주는 함수
	public static double round(double douNum, int n) {
		int one = 1;
		for(int i = 0; i < n; i++) {
			one *= 10;
		}
		double mul = douNum * one;
		long longNum = Math.round(mul);
		double douVal = (double)longNum / one;
		
		return douVal;
	}
	
	
	
	public static void main(String[] args) {
		
		System.out.println(JunitTest.round(3.141592, 3));
	}
	
}
