package Yunjeong.submit12;

public class Book {
	
	private int no;
	private String title;
	private boolean isTaken = false; //true면 대여 false입고중 
	
	
	
	public Book () { }


	public Book(int no, String title) {
		this.no = no;
		this.title = title;
	}


	
	public Book (int no, String title, boolean isTaken) {
		this.no = no;
		this.title = title;
		this.isTaken = isTaken;
	}
	
	
	
	
	@Override
	public String toString() {
		String state = "입고중";
		if(isTaken) {
			state = "대여중";
		}
		return "[책번호: " + no + ", 책 제목: " + title + ", 대여상태=" + state + "]";
	}


	public int getNo() {
		return no;
	}


	public void setNo(int no) {
		this.no = no;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public boolean isTaken() {
		return isTaken;
	}


	public void setTaken(boolean isTaken) {
		this.isTaken = isTaken;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
