package Yunjeong.submit05;

import java.util.Scanner;

public class UpDown {

	public static void main(String[] args) {

		// 랜덤한 수 얻기
//		System.out.println(Math.random());

		// Math.random()은 0~1 t사이의 랜덤 실수를 리턴(생성)한다.
		// Math.random() * 10은 0 ~ 10 사이의 랜덤 실수를 리턴
		// (int) (Math,random() * 10)은 0 ~ 9 중 랜덤 정수
		// 1부터 50까지 중 랜덤한 정수를 얻고싶다
		// ㄴ(int) (Math.random) * 50) + 1 //1을 더하는 것은 0을 포함하냐 안하냐의 의미

//		int randInt = (int) Math.random();
//		System.out.println(randInt);            //결과 0

//		int randInt = (int) (Math.random() * 10);
//		System.out.println(randInt);                   // 0~9까지의 랜덤 정수

		// TODO 반복문 (for문, while문)
		// 사용자로부터 숫자 입력 받음 -- (int)

		// 반복문 종료(break) 조건
		// 1. 정답을 맞춘 경우
		// 2. 5번 반복이 된 경우

		Scanner sc = new Scanner(System.in);

		int randInt = (int) (Math.random() * 50) + 1;

		// Q. 01

		for (int i = 5; i >= 1; i--) {
			System.out.print("숫자를 입력해주세요 :");
			int inputText = Integer.parseInt(sc.nextLine());
			if (inputText == randInt) {
				System.out.println("정답입니다.");
				break;
			} else if (inputText > randInt) {
				System.out.println("다운!! 기회가" + (i-1) + "번 남았습니다.");
			} else if (inputText < randInt) {
				System.out.println("업!! 기회가" + (i-1) + "번 남았습니다.");
				
				
			}
			if (i == 1)
				System.out.println("실패하였습니다. 정답은 " + randInt + "입니다.");
		}

		// Q. 02
		// 사용자의 위치를 입력받고 사용자의 위치와 각 엘리베이터의 층수 차이를 계산
		// 해당 층수 차이에 따른 엘리베이터 이동
		// (층 수 차이가 적은게 이동, 층 수 차이가 같다면, 높은 층에 있는 엘베가 이동)

		int elevatorA = 10;
		int elevatorB = 4;

		while (true) {
			System.out.println("\n============== 희영빌딩 엘리베이터 =================");
			System.out.println("승강기 A의 현재 위치: " + elevatorA + "층");
			System.out.println("승강기 B의 현재 위치: " + elevatorB + "층");
			System.out.print("몇 층에 계시나요? [종료하시려면 q 또는 exit입력]: ");

			String inputText = (sc.nextLine());

			if (inputText.equalsIgnoreCase("q") || inputText.equalsIgnoreCase("exit")) {
				System.out.print("프로그램이 종료되었습니다.");
				break;
			}

			int int1 = Integer.parseInt(inputText);
			int num1 = int1 - elevatorA;
			int num2 = int1 - elevatorB;

			if (num1 < 0) {
				num1 = num1 * (-1);
			}

			if (num2 < 0) {
				num2 = num2 * (-1);
			}
	
			
			if (num1 < num2) {
				System.out.println(int1 + "층에서 엘리베이터를 호출합니다.");
				System.out.println("승강기 A가 " + int1 + "층으로 이동하였습니다.");
			} else if (num2 < num1) {
				System.out.println(int1 + "층에서 엘리베이터를 호출합니다.");
				System.out.println("승강기 B가 " + int1 + "층으로 이동하였습니다.");
			} else if (num1 == num2) {
				if (elevatorA > elevatorB) {
					System.out.println(int1 + "층에서 엘리베이터를 호출합니다.");
					System.out.println("승강기 A가 " + int1 + "층에서 엘리베이터를 호출합니다.");
				}else if (elevatorB > elevatorA) {
					System.out.println(int1 + "층에서 엘리베이터를 호출합니다.");
					System.out.println("승강기 A가 " + int1 + "층에서 엘리베이터를 호출합니다.");
				}
				
			}

		}
	}
}
