package Yunjeong;

import java.util.Scanner;

public class Class {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("n 입력: ");
		String no = sc.nextLine();
		int n = Integer.parseInt(no);
//
//		int result = 0;
//		for (int i = 1; i <= n; i++) {
//			result += i;
//		}
//		System.out.println("1부터 n까지의 합: "+ result);

		System.out.println("===============================================================");

		int[] arr = { 2, 9, 1, 3, 6 };
		for (int i = 0; i < arr.length; i++) {
			for (int k = 0; k < arr.length - 1 - i; k++) {
				if (arr[k] > arr[k + 1]) {
					int tmp = arr[k];
					arr[k] = arr[k + 1];
					arr[k + 1] = tmp;
				}
			}
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}

		System.out.println();

		System.out.println("===============================================================");

		int num = 5;
		System.out.println(Factorial(num));

		System.out.println("===============================================================");

		for (int i = 1; i <= 100; i++) {
			System.out.print(i);

			if (i % 3 == 0) {
				System.out.print("Fizz");
			}
			if (i % 5 == 0) {
				System.out.print("Buzz");
			}
			System.out.println();

		}

		System.out.println("===============================================================");

		String fruit = "사과바나나";
		for (int i = 0; i < fruit.length(); i++) {
			System.out.println(fruit.charAt(i));
		}

		System.out.println("===============================================================");

		String star = "";
		for (int i = 0; i < n; i++) {
			star += "*";
			System.out.println(star);
		}

		String star1 = "";
		for (int i = 0; i < n; i++) {
			star1 += "*";
			String b = "";
			for (int j = 0; j < n - i; j++) {
				b += " ";
			}
			System.out.println(b + star1);
		}


		
		for(int i=0; i<n; i++) {
			String result="";
			for(int k=0; k<n+i; k++) {
				if(k<(n-i)-1) {
					result += " ";
				}else {
					result += "*";
				}
			}
			System.out.println(result);
		}

		
		
		for(int i=0; i<n; i++) {
			String result="";
			for(int k=0; k<n+i; k++) {
				if(k==n-1-i || k==n-1+i || i==n-1) {
					result += "*";
				}else {
					result += " ";
				}
			}
			System.out.println(result);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

	public static int Factorial(int num) {
		if (num == 1) {
			return 1;
		} else {
			return num * Factorial(num - 1);
		}
	}

}
