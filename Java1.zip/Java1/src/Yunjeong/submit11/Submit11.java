package Yunjeong.submit11;

import java.util.ArrayList;
import java.util.Collections;

public class Submit11 {

	public static void main(String[] args) {
		
		ArrayList<Product> prodList = new ArrayList<>();
		
		prodList.add(new Product("냉장고", 2000000));
		prodList.add(new Product("TV", 1000000));
		prodList.add(new Product("에어컨", 800000));
		prodList.add(new Product("컴퓨터", 1300000));
		prodList.add(new Product("선풍기", 100000));
		
		
		
		for(int j = 0; j < prodList.size(); j++) {
			for(int i = 0; i < prodList.size()-1-j; i++) {
				if(prodList.get(i).getPrice() > prodList.get(i+1).getPrice()) {
					Product tmp = prodList.get(i);
					prodList.set(i, prodList.get(i+1));
					prodList.set(i+1, tmp);
				}
			}
		}
		
		
		for(int i = 0; i < prodList.size(); i++) {
			System.out.println(prodList.get(i).toString());
		}
		
		
		for(int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i).getName().equals("TV")) {
				System.out.println("인덱스 위치 : " + (i));
			}
			
		}
		
		
		
		
		
	}

}
