package Yunjeong.submit14;

public class CartoonBoard extends Board {
	private String image;

	public CartoonBoard() {
		super();
	}

	public CartoonBoard(int no, String subject, String date, String content) {
		super(no, subject, date, content);
		this.image = image;
	}

	@Override
	public String toString() {
		return "CartoonBoard [image=" + image + "]";
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	
	
	
	
}
