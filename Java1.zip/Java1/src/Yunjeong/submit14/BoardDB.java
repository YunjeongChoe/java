package Yunjeong.submit14;

import java.util.ArrayList;

public class BoardDB {
	
	public ArrayList<Board> boardList = new ArrayList<>();
	
	
	public void regist(int no, String subject, String date, String content) {
		boardList.add(new Board(no, subject, date, content));
	}
	
	
	public void showList() {
		for(int i = 0; i < boardList.size(); i++) {
			System.out.println(boardList.get(i));
		}
		
		
	}

}
