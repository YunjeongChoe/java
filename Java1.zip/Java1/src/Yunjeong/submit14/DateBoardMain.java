package Yunjeong.submit14;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import ch09_class.school.Student;

public class DateBoardMain {

	public static void main(String[] args) throws ParseException {
		// dbList에 랜덤 날짜를 가지는 DateBoard 객체 30개 삽입
		ArrayList<DateBoard> dbList = new ArrayList<DateBoard>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");

		for (int i = 0; i < 30; i++) {
			int randMonth = (int) (Math.random() * 5) + 1; // 1~5
			int randDay = (int) (Math.random() * 28) + 1; // 1~28
			Calendar cal = Calendar.getInstance();
			cal.set(2022, randMonth - 1, randDay);

			String strDate = sdf.format(cal.getTime());
			dbList.add(new DateBoard(i + "번째 생성된 글", strDate));
		}

		for (int i = 0; i < dbList.size(); i++) {
			System.out.println(dbList.get(i));
		}

		// TODO 코드작성 시작 ~!!
		System.out.println();
		System.out.println("날짜별로 정렬 후 출력(최신순)");
		for (int j = 0; j < dbList.size(); j++) {
			for (int i = 0; i < dbList.size() - 1 - j; i++) {
				Date date1 = sdf.parse(dbList.get(i).getDate());
				Date date2 = sdf.parse(dbList.get(i + 1).getDate());
				//date1 < date2면 최신순
				//date1 > date2면 오래된
				if (date1.getTime() < date2.getTime()) {
					DateBoard tmp = dbList.get(i);
					dbList.set(i, dbList.get(i + 1));
					dbList.set(i + 1, tmp);
				}
			}
		}
		for (int i = 0; i < dbList.size(); i++) {
			System.out.println(dbList.get(i));
		}

		
		
		System.out.println("\n==============================\n");
		
		
		
		
		System.out.println();
		System.out.println("날짜별로 정렬 후 출력(오래된 순)");
		for (int j = 0; j < dbList.size(); j++) {
			for (int i = 0; i < dbList.size() - 1 - j; i++) {
				Date date1 = sdf.parse(dbList.get(i).getDate());
				Date date2 = sdf.parse(dbList.get(i + 1).getDate());
				if (date1.getTime() > date2.getTime()) {
					DateBoard tmp = dbList.get(i);
					dbList.set(i, dbList.get(i + 1));
					dbList.set(i + 1, tmp);
				}
			}
		}
		for (int i = 0; i < dbList.size(); i++) {
			System.out.println(dbList.get(i));
		}

		System.out.println("\n===========4===================\n");
		
		
		//4
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		for (int i = 0; i < dbList.size(); i++) {
			Date date1 = sdf.parse(dbList.get(i).getDate());
			sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			sdf.format(date1);
			Date date2 = cal.getTime();
			if (date1.getTime() > date2.getTime()) {
				DateBoard temp = dbList.get(i);
				System.out.println(temp);
			}
		}

		System.out.println("\n===========5===================\n");

		// 5
		Calendar anyCal = Calendar.getInstance();
		int thismonth = anyCal.get(Calendar.MONTH) + 1;
		int year = anyCal.get(Calendar.YEAR);
		System.out.println("이번 달 작성된 게시글");
		for (int i = 0; i < dbList.size(); i++) {
			Date date1 = sdf.parse(dbList.get(i).getDate());
			anyCal = Calendar.getInstance();
			anyCal.setTime(date1);
			int may = anyCal.get(Calendar.MONTH) + 1;
			int dataYear = anyCal.get(Calendar.YEAR);
			if ((thismonth == may) && (year == dataYear)) {
				System.out.println(dbList.get(i));
			}
		}
		
		System.out.println("\n=============6=================\n");
		
		
		//6
		Calendar cal2 = Calendar.getInstance();
		int month = cal2.get(Calendar.MONTH) - 2;
		System.out.println("2월에 작성된 게시글");
		for (int i = 0; i < dbList.size(); i++) {
			Date date2 = sdf.parse(dbList.get(i).getDate());
			cal2 = Calendar.getInstance();
			cal2.setTime(date2);
			int feb = cal2.get(Calendar.MONTH) + 1;
			if (month == feb) {
				System.out.println(dbList.get(i));
			}
		}
		
		
		System.out.println("\n==============7================\n");

		//7
		String feb = "2022.02.14";
		String mar = "2022.03.21";
		sdf = new SimpleDateFormat("yyyy.MM.dd");
		Date feb1 = sdf.parse(feb);
		Date mar1 = sdf.parse(mar);

		for(int i = 0; i < dbList.size(); i++) {
			Date date1 = sdf.parse(dbList.get(i).getDate());
			DateBoard temp = dbList.get(i);
			
			if((date1.getTime() > feb1.getTime()) && (date1.getTime() < mar1.getTime())) {
			
			System.out.println(temp);
		}
		}
		
		
		
		
		

	}
}
