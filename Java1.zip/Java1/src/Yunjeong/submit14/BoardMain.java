package Yunjeong.submit14;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class BoardMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		BoardDB brdDB = new BoardDB();
		
		
		while(true) {
			System.out.println("행동을 선택해주세요.");
			System.out.println("1. 글 목록 | 2. 글 쓰기 | 3. 종료");
			System.out.print(">>>");

			int command = Integer.parseInt(sc.nextLine());
			
			if(command == 1) {
				//TODO 글 목록
				brdDB.showList();
				
			}
			if(command == 2) {
				//TODO 글 쓰기
				Date dateToday = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
				String strToday = sdf.format(dateToday);
				System.out.print("글 제목을 입력해주세요: ");
				String subject = sc.nextLine();
				System.out.print("글 내용을 입력해주세요: ");
				String content = sc.nextLine();
				brdDB.regist(brdDB.boardList.size()+1, subject, strToday, content);
				
				
				
			}
			if(command == 3) {
				System.out.println("종료합니다.");
				break;
				
			}
		}
		
			
	}

}
