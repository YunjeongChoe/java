package Yunjeong.submit14;

public class AudioBoard extends Board {
	private String audio;

	public AudioBoard() {
		super();
	}

	public AudioBoard(int no, String subject, String date, String content) {
		super(no, subject, date, content);
		this.audio = audio;
	}

	@Override
	public String toString() {
		return "AudioBoard [audio=" + audio + "]";
	}

	public String getAudio() {
		return audio;
	}

	public void setAudio(String audio) {
		this.audio = audio;
	}
	
	
	
	
	
	
	
	
}


