package Yunjeong.submit13;

import java.util.ArrayList;
import java.util.Scanner;

public class McDonaldsMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		McDonalds mcNal = McDonalds.getInstance();

		ArrayList<Menu> cart = new ArrayList<>();

		System.out.println("선택하세요.");
		System.out.println("[1. 매장 내 | 2. TakeOut | 3. 취소]");
		System.out.print(">>> ");
		int choose = Integer.parseInt(sc.nextLine());

		// 매장내
		while (true) {
			if (choose == 1) {
				System.out.println("메뉴를 선택해주세요.");
				System.out.println("[1. 단품 | 2. 디저트 | 3. 카트보기 | 4. 결제]");
				System.out.print(">>> ");
				int option = Integer.parseInt(sc.nextLine());

				if (option == 1) {
					System.out.println(mcNal.burger);
					System.out.print(">>> ");
					String nmB = sc.nextLine();
					
					
					
					

				}if (option == 2) {
					System.out.println(mcNal.dessert);
					System.out.print(">>> ");
					String nmD = sc.nextLine();

					ArrayList<Menu> searchDsrt = mcNal.getSearchDsrt(nmD);

					for (Menu menu : searchDsrt) {

					}
					System.out.println(nmD + "를 카트에 담았습니다.");
					

				}if (option == 3) {
					//TODO 카트보기
					System.out.println(cart);
					
					
					
				}if (option == 4) {
					System.out.println("결제 방식을 선택해주세요.");
					System.out.println("1. 현금 | 2. 카드");
					int payWay = Integer.parseInt(sc.nextLine());
					if (payWay == 1) {
						System.out.println("현금 결제를 선택하셨습니다.");
					}else {
						System.out.println("카드 결제를 선택하셨습니다.");
					}
				}

			} else if (choose == 2) {
				System.out.println("메뉴를 선택해주세요.");
				System.out.println("[1. 단품 | 2. 디져트]");
				System.out.print(">>> ");
				int tOoption = Integer.parseInt(sc.nextLine());

			}

		}
	}

}
