package Yunjeong.submit13;

import java.util.ArrayList;


public class McDonalds {
	
	private ArrayList<Menu> menuList = new ArrayList<>();
	
	public ArrayList<Menu> burger;
	public ArrayList<Menu> dessert;
	
	private McDonalds() {

		burger = new ArrayList<>();
		burger.add(new Menu("더블 치즈 버거", 6000));
		burger.add(new Menu("맥스파이시 상하이 버거", 8500));
		burger.add(new Menu("베이컨 토마토 디럭스", 7200));

		
		dessert = new ArrayList<>();
		dessert.add(new Menu("맥플러리", 3200));
		dessert.add(new Menu("애플파이", 2500));
		dessert.add(new Menu("소프트콘", 1000));
				
		
	}
		

	private static McDonalds instance = new McDonalds();
	
	
	public static McDonalds getInstance() {
		return instance;
		
	}
	
	
	public Menu getSearchBurger (String keyword) {
		for(Menu menu : burger) {
			if(menu.getName().equals(keyword)) {
				return menu;
			}
		}
		return null;
	}
	
	
	public ArrayList<Menu> getSearchDsrt (String keyword) {
		ArrayList<Menu> resultDsrt = new ArrayList<>();
		for(Menu menu : dessert) {
			if(menu.getName().equals(keyword)) {
				resultDsrt.add(menu);
			}
		}
		return resultDsrt;
	}
	
	
	
	
	
	
	
	

}
