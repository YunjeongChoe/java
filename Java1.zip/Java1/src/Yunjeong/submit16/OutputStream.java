package Yunjeong.submit16;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class OutputStream {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String txt = sc.next();
		
		String txt_path = "/home/pc31/test/hi.txt";
		
		try (FileOutputStream fos = new FileOutputStream(txt_path, true);) {
			
			fos.write(txt.getBytes());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
}
