package Yunjeong.submit16;

import java.util.Scanner;

public class PersonalInfo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("이름을 입력하세요. >>>");
		String name = sc.nextLine();
		System.out.print("생년월일을 입력하세요. >>>");
		String dob = sc.nextLine();
		System.out.print("연락처를 입력하세요. >>>");
		String phone = sc.nextLine();
		System.out.print("이메일을 입력하세요. >>>");
		String mail = sc.nextLine();
		
		System.out.println("사용자 정보 : " + name + dob + phone + mail);
		
	}

}
