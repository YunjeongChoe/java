package Yunjeong.submit09;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.swing.plaf.basic.BasicScrollPaneUI.HSBChangeListener;

public class Submit09 {

	public static void main(String[] args) {

//		// Q 01
//
//		ArrayList<Integer> randNum = new ArrayList<Integer>();
//		//2.
//		int result = 0;
//		for (int i = 10; i <= 20; i++) {
//			int randInt = (int) ((Math.random() * 11) + 10);
//			randNum.add(randInt);
//		}
//		System.out.print("01.");
//		System.out.println(randNum);
//		
//		
//		
//		ArrayList<Integer> finNum = new ArrayList<Integer>();
//		//3.
//		for (int i = 0; i < randNum.size(); i++) {
//			if(!finNum.contains(randNum.get(i))) {
//				finNum.add(randNum.get(i));				
//			}
//		}
//		for(int i = 0; i < finNum.size(); i++) {
//			System.out.print(finNum.get(i) + " ");
//		}
//		
//		System.out.println();
//		
//		//4. 오름차순 정렬 
//		 List<Integer> tempList = new ArrayList<Integer>();
//		Collections.sort(finNum);
//		for(int i = 0; i < finNum.size(); i++) {
//			tempList.add(finNum.get(i));
//		}
//		System.out.println(tempList);
//		
//		
//		
//		//5. 내림차순 정렬 
//		Collections.sort(finNum, Collections.reverseOrder());
//		System.out.println(finNum);
		
		
		
		

		System.out.println("\n=======================Q. 01 풀이=============================\n");
		
		//step 1 정수를 담을 수 있는 ArrayList 객체를 생성 
		ArrayList<Integer> randNum = new ArrayList<Integer>();
		
		//step 2 10부터 20 사이의 랜덤 숫자를 10개 담기
		
		for (int i = 0; i < 10; i++) {
			int randInt = (int) ((Math.random() * 11) + 10);
			randNum.add(randInt);
		}
		System.out.println("randNum: " + randNum);
		
		//step 4 한 줄로 출력
		for (int i = 0; i < randNum.size(); i++) {
			System.out.print(randNum.get(i) + " ");
		}
		
		System.out.println();
		
		//step 5 중복된 숫자 제거
		// 새로운 배열에 옮기기
		ArrayList<Integer> newList = new ArrayList<Integer>();
		for (int i = 0; i < randNum.size(); i++) {
			if(newList.indexOf(randNum.get(i)) == -1) {
			newList.add(randNum.get(i));
			}
		}
		for(int i = 0; i < newList.size(); i++) {
			System.out.print(newList.get(i) + " ");
		}
		
		System.out.println();
		
		
		//step 6
		//오름차순
		Collections.sort(randNum);
		for (int i = 0; i < randNum.size(); i++) {
			System.out.print(randNum.get(i) + " ");
		}
		
		
		//step 7 내림차순 
		//단축키 Alt + Shift + R
		for(int k = 0; k < randNum.size(); k++) {
			for(int i = 0; i < randNum.size()-1-k; i++) {
				if(randNum.get(i) < randNum.get(i+1)) {
					int tmp = randNum.get(i);
					randNum.set(i, randNum.get(i+1));
					randNum.set(i+1, tmp);
				}
			}
		}
		
		
		
		
		System.out.println("\n========================// Q. 01 [두번째 방법] 새로운 배열 없이 중복 제거============================\n");
		
		for(int i = 0; i < randNum.size()-1; i++) {
			for(int k = randNum.size()-1; k > 1; k--) {               //k를 거꾸로 돌려야 인덱스 바뀌는거 없이 중복을 제거할 수 있음 (앞으로 돌리면 인덱스가 바뀌어서 중복 제거 불가능)
				if(randNum.get(i) == randNum.get(k)) {
					randNum.remove(k);
				}
			}
			
		}for (int i = 0; i < randNum.size(); i++) {
			System.out.print(randNum.get(i) + " ");
		}
		System.out.println(randNum);
		
		
		
		
		
		

		// Q 02

//		ArrayList<String> wifeShoplist = new ArrayList<String> ();
//		ArrayList<String> husbandShoplist = new ArrayList<String> ();
//		
//		wifeShoplist.add("냉장고");
//		wifeShoplist.add("세탁기");
//		wifeShoplist.add("에어컨");
//		System.out.println("아내가 사고 싶은 물건 " + wifeShoplist);
//		
//		husbandShoplist.add("노트북");
//		husbandShoplist.add("TV");
//		husbandShoplist.add("에어컨");
//		System.out.println("남편이 사고 싶은 물건 " + husbandShoplist);
//		
//		
//		
//		String[] common = new String[1];
//		System.out.println("wifeShoplist.size : " + wifeShoplist.size());
//		for(int i = 0; i < wifeShoplist.size(); i++) {
////			System.out.println(wifeShoplist.get(i));
//			for(int k = 0; k < husbandShoplist.size(); k++) {
////				System.out.println(husbandShoplist.get(i));
//				if(wifeShoplist.get(i).equals(husbandShoplist.get(k))) {
//					System.out.println(wifeShoplist.get(i));
//					common[0] = wifeShoplist.get(i);
//					
//				}
//			}
//		}
//		System.out.println("서로 사고싶은 물건 : " + common[0]);
		
		
//		String[] shopList = new String[5];
//		int cnt = 0;
//		for(int i = 0; i < wifeShoplist.size(); i++) {
//			for(int k = 0; k < husbandShoplist.size(); k++) {
//				shopList[cnt]=wifeShoplist.get(i); 
//				cnt++;
//				if(wifeShoplist.get(i).equals(husbandShoplist.get(k))) {
//					System.out.println("서로사고싶은물건 : "+wifeShoplist.get(i));
//				}else {
//					System.out.println("wifeShoplist: " + wifeShoplist);
//				
//					for(int m=0; m< shopList.length; m++) {
//						if(!shopList[m].equals(husbandShoplist.get(k)))
//						shopList[cnt]=husbandShoplist.get(k); 
//						cnt++;
//						
//					}
//					
//					
//				}
//			
//			}
//		}
		
		
		System.out.println("\n=====================Q. 02 풀이===============================\n");
		
		
		ArrayList<String> wifeShoplist = new ArrayList<String> ();
		wifeShoplist.add("냉장고");
		wifeShoplist.add("세탁기");
		wifeShoplist.add("에어컨");
		wifeShoplist.add("로봇청소기");
		
		ArrayList<String> husShoplist = new ArrayList<String> ();
		husShoplist.add("노트북");
		husShoplist.add("TV");
		husShoplist.add("에어컨");
		husShoplist.add("로봇청소기");
		
		//서로 사고싶은 물건 목록
		ArrayList<String> common = new ArrayList<>();
		
		for(int i = 0; i < wifeShoplist.size(); i++) {
			if(husShoplist.indexOf(wifeShoplist.get(i)) != -1) {
				common.add(wifeShoplist.get(i));
			}
		}
		System.out.println(common);
		
		
		
		//교집합을 위한 함수. .retainAll() 이용
		
		common = new ArrayList<>();
		
		common.addAll(wifeShoplist);
		System.out.println(common);
		common.retainAll(husShoplist);
		System.out.println(common);
		
		
		//전체 구매 목록 (합집함)
		ArrayList<String> allBuy = new ArrayList<>();
		
		for(int i = 0; i < wifeShoplist.size(); i++) {
			allBuy.add(wifeShoplist.get(i));
			
		}
		for(String item : husShoplist) {
			if(allBuy.indexOf(item) == -1) {                     //가지고 있지 않을 때 -1
				allBuy.add(item);
			}
			
		}
		System.out.println(allBuy);
		
		
		
		
		
		
		
		
		
	}

}
