package Yunjeong.submit15;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import Yunjeong.submit15.model.BoardVO;
import Yunjeong.submit15.model.MemberVO;
import Yunjeong.submit15.service.BoardService;
import Yunjeong.submit15.service.MemberService;

public class HompageMain {

	public static void main(String[] args) {

		MemberService memService = MemberService.getInstance();
		BoardService brdService = BoardService.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm");

		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("행동을 선택해주세요.");
			System.out.println("1. 회원가입 | 2. 로그인 | 3.종료");
			System.out.print(">>>");

			int command = 0;

			try {
				command = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("숫자를 입력해주세요");
				continue;
			}

			// 회원가입
			if (command == 1) {
				System.out.print("아이디를 입력해주세요: ");
				String id = sc.nextLine();
				System.out.print("비밀번호를 입력해주세요: ");
				String pw = sc.nextLine();
				MemberVO temp = new MemberVO(id, pw);
				int num = memService.insertMem(temp);
				if (num != 0) {
					System.out.println("회원가입이 완료되었습니다.");
				}

			} else if (command == 2) {
				// 로그인
				System.out.print("아이디를 입력해주세요: ");
				String id = sc.nextLine();
				System.out.print("비밀번호를 입력해주세요: ");
				String pw = sc.nextLine();

				MemberVO login = memService.loginMem(id);

				if (pw.equals(login.getMemPassword())) {
					System.out.println("로그인 되었습니다.");

						
						while(true) {
							ArrayList<BoardVO> brdList = brdService.getBoardList();
							for (int i = 0; i < brdList.size(); i++) {
								System.out.println(brdList.get(i).toString());
							}
							
							System.out.println("행동을 선택해주세요.");
							System.out.println("1. 글쓰기 | 2. 글조회 | 3. 로그아웃");
							System.out.print(">>>");
							
							int num = 0;
							try {
								num = Integer.parseInt(sc.nextLine());
							} catch (NumberFormatException e) {
								System.out.println("숫자를 입력하세요.");
								continue;
							}

							
							
							if (num == 1) {
								System.out.print("글 제목을 입력해주세요.");
								String title = sc.nextLine();
								System.out.print("글 내용을 입력해주세요.");
								String content = sc.nextLine();

								
								Date time = new Date();
								String date = sdf.format(time);

								BoardVO board = new BoardVO(0, title, content, login.getMemId(), date);
								int count = brdService.insertPost(board);
								
								if(count > 0) {
									System.out.println("글 작성이 완료되었습니다.");
								}else {
									System.out.println("글 작성에 실패하였습니다.");
								}
								
								
								
								
								
							} else if(num == 2){
								//글조회
								System.out.println("글 번호를 입력해 주세요");
								System.out.print(">>> ");
								
								int no = Integer.parseInt(sc.nextLine());
								
								BoardVO board = brdService.getBoard(no);
								
								if(board != null) {
									System.out.println("=========================");
									System.out.println("제목: " + board.getTitle());
									System.out.println("작성자: " + board.getWriter());
									System.out.println("작성일: " + board.getDate());
									System.out.println("내용: " + board.getContent());
									System.out.println("=========================");
								}else {
									System.out.println("해당 글번호는 존재하지 않습니다.");
								}
							
							}else if (num ==3) {
								//로그아웃
								break;
							
							}else {
								System.out.println("잘못 입력하셨습니다.");
							}
						}
				}else {
					System.out.println("비밀번호가 일치하지 않습니다.");
				}
			}else {
				System.out.println("존재하지 않는 아이디입니다.");
			} if(command == 3) {
				System.out.println("종료합니다.");
				break;
			}else {
			System.out.println("잘못 입력하셨습니다.");
			}
			
		}

	}

}
