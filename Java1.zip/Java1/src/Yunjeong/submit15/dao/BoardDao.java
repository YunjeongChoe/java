package Yunjeong.submit15.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Yunjeong.submit15.model.BoardVO;

public class BoardDao {
	
	private static BoardDao instance = new BoardDao();
	
	public static BoardDao getInstance() {
		return instance;
	}
	
	private BoardDao() {
		
	}
	
	
	public BoardVO getBoard(Connection conn, int no) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		, bo_no				");
		query.append("		  bo_title			");
		query.append("		, bo_content		");
		query.append("		, bo_writer	 		");
		query.append("		, bo_date	 		");
		query.append("FROM						");
		query.append("		boards				");
		query.append("WHERE 1=1					");
		query.append("AND no = ?				");
		
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setInt(idx++, no);
		
		ResultSet rs = ps.executeQuery();
		
		BoardVO result = new BoardVO();
		
		while(rs.next()) {
			BoardVO temp = new BoardVO();
			temp.setNo(rs.getInt("no"));
			temp.setTitle(rs.getString("title"));
			temp.setContent(rs.getString("content"));
			temp.setWriter(rs.getString("writer"));
			temp.setDate(rs.getString("date"));
			

		}
		
		if(rs != null) rs.close();
		if(ps != null) ps.close();
		
		return result;
	}
	
	
	
	
	
	//게시글불러오기 
	public ArrayList<BoardVO> getBoardList(Connection conn) throws SQLException{
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		, bo_no				");
		query.append("		  bo_title			");
		query.append("		, bo_content		");
		query.append("		, bo_writer	 		");
		query.append("		, bo_date	 		");
		query.append("FROM						");
		query.append("		boards				");
		query.append("ORDER BY bo_no DESC		");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<BoardVO> result = new ArrayList<>();
		
		while(rs.next()) {
			BoardVO temp = new BoardVO();
			temp.setNo(rs.getInt("no"));
			temp.setTitle(rs.getString("title"));
			temp.setContent(rs.getString("content"));
			temp.setWriter(rs.getString("writer"));
			temp.setDate(rs.getString("date"));
			
			result.add(temp);
		}
		
		if(ps != null) ps.close();
		if(rs != null) rs.close();
		
		return result;
		
	}
	
	//글쓰기 (INSERT)
	public int insertPost (Connection conn, BoardVO pst) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO								");
		query.append("		  boards							");
		query.append("VALUES	(								");
		query.append("		  (SELECT COUNT (*)+1 FROM boards)	");
		query.append("		, ?	 								");
		query.append("		, ?	 								");
		query.append("		, ?	 								");
		query.append("		, ?	 								");
		query.append("		)									");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());

		int idx = 1;
		ps.setString(idx++, pst.getTitle());
		ps.setString(idx++, pst.getContent());
		ps.setString(idx++, pst.getWriter());
		ps.setString(idx++, pst.getDate());

		int cnt = ps.executeUpdate();
		if (ps != null)ps.close();

		return cnt;
		
	}
	
	
	
	
	
	
}
