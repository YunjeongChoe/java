package Yunjeong.submit15.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Yunjeong.submit15.model.MemberVO;
import ch14_jdbc_jsp.model.StudentVO;


public class MemberDao {

	private static MemberDao instance = new MemberDao();

	public static MemberDao getInstance() {
		return instance;
	}

	private MemberDao() {

	}

	// 회원가입 (INSERT / DAO에서는 항상 connection 넣어줘여ㅑ됨)
	public int insertMem(Connection conn, MemberVO mem) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO			");
		query.append("		  members		");
		query.append("VALUES	(			");
		query.append("		  ?				");
		query.append("		, ?	 			");
		query.append("		)				");

		PreparedStatement ps = conn.prepareStatement(query.toString());

		int idx = 1;
		ps.setString(idx++, mem.getMemId());
		ps.setString(idx++, mem.getMemPassword());

		int cnt = ps.executeUpdate();
		if (ps != null)
			ps.close();

		return cnt;

	}

	// 로그인
	public MemberVO loginMem(Connection conn, String id) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("		  mem_id			");
		query.append("		, mem_password		");
		query.append("FROM						");
		query.append("		members				");
		query.append("WHERE 1=1					");
		query.append("	AND mem_id = ?			");

		PreparedStatement ps = conn.prepareStatement(query.toString());

		int idx = 1;
		ps.setString(idx++, id);

		ResultSet rs = ps.executeQuery();

		MemberVO result = new MemberVO();

		while (rs.next()) {
			result.setMemId(rs.getString("mem_id"));
			result.setMemPassword(rs.getString("mem_password"));
		}

		if (ps != null)
			ps.close();
		if (rs != null)
			rs.close();

		return result;
	}
	
	//중복체크용
//	public boolean dupleCheck(Connection conn, String id) {
//		StringBuffer query = new StringBuffer();
//		query.append("SELECT					");
//		query.append("		  COUNT(*) AS cnt	");
//		query.append("FROM						");
//		query.append("		members				");
//		query.append("WHERE 1=1					");
//		query.append("	AND mem_id = ?			");
//		//있으면 1  없으면 0
//		// 4. 쿼리문 실행과 동시에 결과를 ResultSet 객체에 담는다.
//		
//		PreparedStatement ps = conn.prepareStatement(query.toString());
//		
//		int idx=1;
//		ps.setString(idx++, id);
//		
//		ResultSet rs = ps.executeQuery();
//		
//		int cnt = 0;
//		
//		// 5. 실행결과인 rs를 이용하여 데이터조회
//		while (rs.next()) {
//			rs.getInt("cnt");
//		}
//			
//
//		if (ps != null)ps.close();
//		if (rs != null)rs.close();
//
//		if(cnt ==1) {
//			return true;
//		}else {
//			return false;
//		}

	
	
}
