package Yunjeong.submit15.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import Yunjeong.submit15.dao.MemberDao;
import Yunjeong.submit15.jdbc.ConnectionPool;
import Yunjeong.submit15.model.MemberVO;



public class MemberService {
	
	private MemberDao dao = MemberDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static MemberService instance = new MemberService();
	
	public static MemberService getInstance() {
		return instance;
	}
	
	private MemberService() {
		
	}

	
	
	//로그인
	public MemberVO loginMem(String id) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.loginMem(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		return new MemberVO();
	}
	
	
	//회원가입(INSERT)
		public int insertMem(MemberVO mem) {
			Connection conn = cp.getConnection();
		

			
			try {
				return dao.insertMem(conn, mem);
//				return dao.insertMem(conn, mem); try/catch문
			} catch (SQLException e) {
				System.out.println("중복된 아이디입니다.");
			}finally {
				if(conn != null) cp.releaseConnection(conn);
			}

			return 0;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
