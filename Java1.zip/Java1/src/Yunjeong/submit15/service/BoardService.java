package Yunjeong.submit15.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import Yunjeong.submit15.dao.BoardDao;
import Yunjeong.submit15.jdbc.ConnectionPool;
import Yunjeong.submit15.model.BoardVO;
import Yunjeong.submit15.model.MemberVO;


public class BoardService {
	
	
	private BoardDao dao = BoardDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static BoardService instance = new BoardService();
	
	public static BoardService getInstance() {
		return instance;
	}
	
	private BoardService() {
		
	}
	
	//글 목록 보기
	public ArrayList<BoardVO> getBoardList(){
		Connection conn = cp.getConnection();
		
		try {
			return dao.getBoardList(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return new ArrayList<BoardVO>();
	}
	
	
	//글 쓰기(INSERT)
	public int insertPost (BoardVO pst) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.insertPost(conn, pst);
		} catch (SQLException e) {
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return 0;
	}
	
	
	// 글 조회
	public BoardVO getBoard(int no) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.getBoard(conn, no);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return null;
	}
	
	

}
