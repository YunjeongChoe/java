package Yunjeong.submit10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Submit10 {

	public static void main(String[] args) {
		System.out.println("\nQ. 01-----------------------------------\n");
//		Hint
//		while문 내에서 HashSet에 랜덤 로또 번호를 HashSet의 사이즈가 6개가 될 때까지 넣는다.

//		HashSet<Integer> makeLotto = new HashSet<Integer>();
//
//		while (makeLotto.size() < 6) {
//			int randInt = (int) (Math.random() * 45) + 1;
//			makeLotto.add(randInt);
//		}
//		System.out.println(makeLotto);
//
////		이후 HashSet을 ArrayList로 변환한 다음, 오름차순으로 ArrayList를 정렬하여 리턴한다.	
//		ArrayList<Integer> tempArr = new ArrayList<Integer>();
//		tempArr.addAll(makeLotto);
//		System.out.println(tempArr);
//
//		Collections.sort(tempArr);
//		System.out.println(tempArr);
		
		
		
		
//		ArrayList<Integer> myLotto = makeLotto<>();
//		System.out.println(myLotto);
		
		
		
		
		
		
		
		
		
		
		
		

		System.out.println("\nQ. 02-----------------------------------\n");

		HashMap<String, String> infoMap = new HashMap<>();

		infoMap.put("a001", "1234a");
		infoMap.put("b001", "1234b");
		infoMap.put("c001", "1234c");
		infoMap.put("d001", "1234d");
		infoMap.put("e001", "1234e");

		Scanner sc = new Scanner(System.in);

		System.out.println("아이디를 입력해주세요");
		System.out.print(">>>");
		String inputId = sc.nextLine();
		System.out.println("비밀번호를 입력해주세요");
		System.out.print(">>>");
		String inputPwd = sc.nextLine();

		if (infoMap.containsKey(inputId) == true) {
			if (infoMap.containsValue(inputPwd) == true) {
				System.out.println("로그인에 성공하였습니다.");
			}
		}
		if (infoMap.containsKey(inputId) == false) {
			System.out.println("존재하지 않는 아이디입니다.");
		} 
		if (infoMap.containsValue(inputPwd) == false) {
			System.out.println("비밀번호가 틀렸습니다.");
		}
		
		
		
//		static ArrayList<Integer> makeLotto() {
//			HashSet<Integer> tempSet = new HashSet<Integer>();
//			while(tempSet.size() < 6) {
//				int randInt = (int) (Math.random() * 45) + 1;
//				tempSet.add(randInt);
//				
//			}
//		}
//		
//		ArrayList<Integer> resultList = new ArrayList<Integer>();
//		resultList.addAll(tempSet);
//		Collections.sort(resultList);
//		return resultList;
		
		
		
		
		
	}

}
