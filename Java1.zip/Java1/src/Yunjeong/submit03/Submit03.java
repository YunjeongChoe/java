package Yunjeong.submit03;

import java.util.Scanner;

public class Submit03 {

	public static void main(String[] args) {
		
		
		//Q. 01
		Scanner scn = new Scanner(System.in);
		
		System.out.println("국어 점수를 입력해주세요.");
		System.out.print(">>>");
		String korean = scn.nextLine();
		System.out.println("영어 점수를 입력해주세요.");
		System.out.print(">>>");
		String english = scn.nextLine();
		System.out.println("수학 점수를 입력해주세요.");
		System.out.print(">>>");
		String math = scn.nextLine();
		
		String str1 = korean;
		String str2 = english;
		String str3 = math;
		
		int int1 = Integer.parseInt(str1);
		int int2 = Integer.parseInt(str2);
		int int3 = Integer.parseInt(str3); 
		
		System.out.println("평균: " + ((double)int1 + int2 + int3) / 3);
		double avg = (int1 + int2 + int3) / 3;
		String grade = (avg > 90) ? "A등급" : ((avg > 80) ? "B등급" : "C등급");
		System.out.println(grade);
		
		
//		int korea + Integer.parseInt(scn.nextLine());
//		double doubleAvg = (kor + eng + math) / 3.0;
//		syso("평균: " + doubleAvg);
//		
//		//실수 반올림
//		int avg = Math.round(doubleAvg);
//		System.out.println("반올림한 평균: " + avg);
//		
//		if(avg >= 90 ) {
//			System.out.println("A 등급");
//		}else if(avg >= 80) {
//			System.out.println("B 등급");
//		}else if (avg >= 70) {
//			System.out.println("C 등급");
//		}else {
//			System.out.println("D 등급");
//		}
			
		
		
		
		
		
		
		
		
		
		
		
		
		scn.close();
		
		System.out.println("\n======================================================================\n");
		
		
		//Q. 02
//		int result = 1;
//		for(int i = 10; i >= 1; i--) {
//			result *= i;
//		}
//		System.out.println("결과: " + result);
//		
//		long addRslt = 1;
//		for(long i = 1; i <= 15; i++) {
//			addRslt *= i;
//		}
//		System.out.println("결과: " + addRslt);
		
		//10!
		int facTen = 1;
		for(int i = 1; i <= 10; i ++) {
			facTen *= i;
		}
		System.out.println(facTen);
		
		//15!
		long facResult = 1;
		for(int i = 1; i <= 15; i ++) {
			facResult *= i;
		}
		System.out.println(facResult);
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("\n======================================================================\n");
		
		
		
		//Q. 03
		String findWally = "윌리울리일리울리울리일리월리일리윌리월리울리일리일리월리일리윌리일리윌리일리월리월리윌리울리윌리울리일리울리울리윌리일리";

//		int count = 0;
//		for(int i = 0; i < findWally.length(); i+=2) {
//			String str = findWally.substring(i, i+2);
//			String name = "월리";
//			if(str.equals(name)) {
//				count ++;
//			}
//		}
//		System.out.println("결과: " + count);
		
		int countWally = 0;
		for(int i = 0; i < findWally.length() - 1; i++) {
			String twoWord = findWally.substring(i, i+2);
			
			if(twoWord.equals("월리")) {
				countWally ++;
			}
		}
		System.out.println("월리는 총 " + countWally);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("\n======================================================================\n");
		//Q. 04
		
		String star = "*****";
		for(int i=5; i>0; i--) {
			star = star.substring(0, i);
			 	System.out.println(star);
		}
		
		//String star = "*****";
		//for(int i = 0; i < 5; i++){
		//System.out.println(star.substring(i));
		//}
		
		
		
		
		
		
		
	}
	
}

