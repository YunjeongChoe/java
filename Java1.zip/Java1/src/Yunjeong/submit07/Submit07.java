package Yunjeong.submit07;

import java.util.Arrays;

import ch07_array.ArrayStudy;

public class Submit07 {

	public static void main(String[] args) {
		
		
		// Q 01

		
		int[] lottoArr = makeLotto();
		printArray(lottoArr);
		
		//지난주 1등 당첨 번호
		int[] winLotto = {5, 11, 18, 20, 35, 45};
		
		//myLotto와 winLotto를 비교해서 
		//숫자 배열 두개를 입력(파라미터) 받아 전부 다 일치하는 경우 당첨되었다고 출력 - true를 리턴 
		//1개라도 틀리면 - flase를 리턴하는 함수 만들기 
		int count = 0;
		for(int i = 0; i < lottoArr.length; i++) {
			if(lottoArr[i] == winLotto[i]) {
				count++;
			}
		}
		if(count == 6) {
			System.out.println("당첨");
		}else {
			System.out.println("낙첨");
		}
		
		int num = 0;
		while(true) {
			System.out.println((++num) + "회 실행");
			if(checkLotto(winLotto, makeLotto())) {
			System.out.println("1등 당첨!!");
			System.out.println("구매횟수" + num);
			System.out.println("구매 금액: " + (num * 1000l));
			break;
			}
		}
		
		
		
		
		
		
		
		
		
		// Q 02
		int[] intArray = {23, 456, 213, 32, 464, 1, 2, 4};
		
		for(int i = 0; i < intArray.length-1; i++) {
			for(int j = i+1; j < intArray.length; j++) {    
				if(intArray[i] > intArray[j]) {
					int temp = intArray[i];
					intArray[i] = intArray[j];
					intArray[j] = temp;
				}
			}
		}
		for(int i = 0; i < intArray.length; i++) {
			
		}
		printArray(intArray);
		
		
		
		
		
		
		
	}
	
//	static boolean lottoResult(int[] lottoArr, int[] winLotto) {
//		int count = 0;
//		while(true)(i = 0; i < lottoArr.length; i++) {
//			if(lottoArr[i] == winLotto[i]) {
//				count++;
//			}
//						
//		}
//	}	
		
	
	static boolean checkLotto(int[] winArr, int[] myArr) {
		int count = 0;
		for(int i = 0; i < winArr.length; i++) {
			if(winArr[i] ==myArr[i]) {
				count++;
			}
		}
//		if(count == 6) {
//			return true;             return (count == 6)랑 똑같음 
//		}
//		return false;
		return (count == 6);
	}
	
	
	
	
	
	
	
	
	static int[] makeLotto () {
		int[] lottoArr = new int[6];
		int idx = 0;
		while(idx < 6) {
			int randInt = (int) (Math.random() * 45) + 1;
			boolean isDuple = false;
			for(int i = 0; i < lottoArr.length; i++) {
				if(lottoArr[i] == randInt) {
					isDuple = true;
				}
			}
			if(isDuple == false) {
				lottoArr[idx] = randInt;
				idx++;	
				
			}
		}
		Arrays.sort(lottoArr);
		return lottoArr;
	}		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	static void printArray(int[] intArray) {
		for(int i = 0; i < intArray.length; i++) {
			if(i == intArray.length -1) {                           
				System.out.println(intArray[i]);
			}else {				
				System.out.print(intArray[i] + ", ");              
			}
		}
	}
		
	
	
	
	static void printArray(String[] strArray) {
		for(int i = 0; i < strArray.length; i++) {
			if(i == strArray.length -1) {                         
				System.out.println(strArray[i]);
			}else {				
				System.out.print(strArray[i] + ", ");             
			}
		}
	}
	
	
	

}
