package Yunjeong.submit04;

import java.util.Scanner;

public class Submit04 {

	public static void main(String[] args) {

		// 01

		int total = 5834;
		int times = total / 360;
		int degree = total % 360; // 74

		if (degree < 60) {
			System.out.println("사탕");
		} else if ((60 <= degree) && (degree < 120)) {
			System.out.println("초콜릿");
		} else if ((120 <= degree) && (degree < 180)) {
			System.out.println("쿠키");
		} else if ((180 <= degree) && (degree < 240)) {
			System.out.println("콜라");
		} else if ((240 <= degree) && (degree < 300)) {
			System.out.println("아이스크림");
		} else {
			System.out.println("커피");
		}

		System.out.println("바퀴가 돌아간 총 횟수: " + times);

		// 풀이
		int rotateCount = 5834 / 360;
		System.out.println(rotateCount + "바퀴");
		int angle = 5834 % 360;
		if (angle <= 60) {
			System.out.println("사탕");
		} else if (angle <= 120) {
			System.out.println("초콜릿");
		} else if (angle <= 180) {
			System.out.println("쿠키");
		} else if (angle <= 240) {
			System.out.println("콜라");
		} else if (angle <= 240) {
			System.out.println("아이스크림");
		} else {
			System.out.println("커피");
		}

		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("\n========================================\n");

		// 02

		Scanner scn = new Scanner(System.in);

		System.out.print("거꾸로 뒤집을 문자열 입력: ");

		String result = scn.nextLine();
		String str1 = "";
		for (int i = result.length() - 1; i > -1; i--) {
			str1 += result.charAt(i);
		}
		System.out.println(str1);

		scn.close();

		// 풀이
//		Scanner sc = new Scanner(System.in);
//		System.out.println("거꾸로 뒤집을 문자열 입력: ");
//		String inputText = sc.nextLine();
//
//		// '오늘은 수요일' <-length는 7 / 인덱스는 0부터 시작이라 length -1 까지다.
//
//		// charAt 이용
//		for (int i = inputText.length() - 1; i >= 0; i--) {
//			System.out.println(inputText.charAt(i));
//		}
//
//		// substring 이용
//		String reverse = "";
//
//		for (int i = inputText.length() - 1; i >= 0; i--) {
//			System.out.print(inputText.substring(i, i + 1));
//			reverse += inputText.substring(i, i + 1);
//		}
//		System.out.println(reverse);

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("\n========================================\n");

		// 03

		int num = 5;

		for (int i = 0; i < num; i++) {
			for (int j = 1; j < num - i; j++) {
				System.out.print(" ");
			}
			for (int l = 0; l < i * 2 + 1; l++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		
		
		//풀이
		//for문이 1, 2, 3, 4, 5번 실행되는 동안
		//*은 1, 3, 5, 7, 9개,
		//" "은 4, 3, 2, 1, 0개가 된다.
		String star1 = "*";
		for(int i = 0; i < 5; i++) {
			String blank1 = "";
			for(int j = 0; j <  4-i; j++) {
				blank1 += " ";
			}
			System.out.println(blank1 + star1);
			star1 += "**";
		}
		
		//거꾸로 트리 
		//*********
		// *******
		//  *****
		//   ***
		//    *
		//for문이 1, 2, 3, 4, 5번 반복
		//*은 9, 7, 5, 3, 1
		//" "은 0, 1, 2, 3, 4
		String blank2 = "";
		for(int i = 0; i < 5; i++) {
			String star2 = "*";
			for(int j = 0; j < 4-i; j++){
				star2 += "**";
			}
			
			System.out.println(blank2 + star2);
			blank2 += " ";
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
