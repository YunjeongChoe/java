package Yunjeong.submit06;

public class Submit06 {
	
	public static void main(String[] args) {
		
		
		//Q. 01
		
		makeCard("정찬웅", "010-7398-7332", "akow283@gmail.com");
		
		
		System.out.println("\n==========================================\n");
		
		
		//Q. 02
		
		makeTree(5);
		makeTree(7);
		
		
		
		
		// Q. 03
		myBinaryStr(23);
		//String binaryString = integer.toBinaryString(23);   --자동으로 2진수로 바꿔줌
//		System.out.println(binaryString);
		//String hexString = Integer.toHexString(23);
		
		
	}
	
	
	
	/*1생성된 값을 담을 변수 선언
	2.입력받은 값을 2로 나눈 나머지를 변수에 더해준다.
	3.계속 반복
	4.더이상 나눌 값이 없으면 멈춘다.
	5.*/
	
	static void myBinaryStr(int number) {
		String result = "";
		int num = number;
		while(num>0) { 
			result = result + num % 2;
			num = num/2;
			
//			System.out.println("num: " + num);
			String reverse = "";
			for (int i = result.length() - 1; i >= 0; i--) {
				System.out.print(result.substring(i, i + 1));
				reverse += result.substring(i, i + 1);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	//풀이 
//	static String reverse(String str) {
//		for (int i = str.length() - 1; i >= 0; i--) {
//			System.out.print(str.substring(i, i + 1));
//			reverse += str.substring(i, i + 1);
//		}
//		return reverse;
//	}
//	
//	
//	
//	
//	static String myBinaryStr(int num1) {
//		
//		String result = "";
//		while(true) {
//			result += num1 % 2;
//			if(num1 ==1) {
//				break;
//			}
//			num1 /= 2;
//		}
//		String reverseResult = reverse(result);
//		return reverse(result);
//	}
	
	
	
	
	
	
	
	
	
	static void makeTree(int num) {
		String star = "*";
		for(int i = 0; i < num; i++) {
			String blank = "";
			for(int j = 0; j < (num -1)- i; j++) {
				blank +=" ";
			}
			System.out.println((i) + "." + blank + star);
			star += "**";
		}
		
		
	}
	
	
	
	
	
	
	
	
	static void makeCard(String name, String phonNum, String mail) {
		System.out.println("\n=============================\n");
		System.out.println("이름 : " + name);
		System.out.println("연락처 : " + phonNum);
		System.out.println("이메일 : " + mail);
		System.out.println("\n=============================\n");
		
	}
	
	
	
	
	
	
	

}
