package Yunjeong.submit02;

import java.util.Scanner;

public class Submit02 {

	public static void main(String[] args) {
		 
		
		//01
		
		Scanner scanner = new Scanner(System.in);
		
//		System.out.print("이름을 입력해주세요: ");
//		String name = scanner.nextLine();
//		
//		System.out.print("국어 점수를 입력해주세요: ");
//		String korean = scanner.nextLine();
//		
//		
//		System.out.print("영어 점수를 입력해주세요: ");
//		String english = scanner.nextLine();
//		
//		System.out.print("수학 점수를 입력해주세요: ");
//		String math = scanner.nextLine();
//		
//		String str1 = korean;
//		String str2 = english;
//		String str3 = math;
//		
//		int int1 = Integer.parseInt(str1);
//		int int2 = Integer.parseInt(str2);
//		int int3 = Integer.parseInt(str3);
//
//		
//		System.out.println("\n===============================\n");
//		System.out.println("이름: " + name);
//		System.out.println("국어: " + korean);
//		System.out.println("영어: " + english);
//		System.out.println("수학: " + math);
//		System.out.println("평균: " + ((double)int1 + int2 + int3) / 3);
//		System.out.println("\n===============================\n");
//
//		
//		scanner.close();
		
		
		
		
		
		System.out.println("\n=============================================================\n");
		
		
		//02
//		String idBack = "1231476";
//		
//		String num = idBack.substring(0, 1);
//		int intNum = Integer.parseInt(num);
//		
//		String backNum = (intNum % 2 == 1) ? "남성" : "여성";
//		
//		System.out.println(backNum);
		

		
		System.out.println(fibonachi(7));
		System.out.println(fibonachi(8));
		
		

	}
	
	static int fibonachi(int n) {
		int sum = 0;
		for(int i = 0; i < n; i ++) {
			sum = ((n+i) + (n+i)+i);
		}
		
		return sum;
		
	}
	
	
	
	
	

}
