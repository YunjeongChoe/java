package ch06_method;

public class RecursionFunction {

	public static void main(String[] args) {
		
		System.out.println("\n=====================재귀함수========================\n");
		//메소드를 반복 실행하고 싶을 때 사용
		
		//5
		//4
		//3
		//2
		//1
		
		recursionPrint(5);
		
		System.out.println("\n=============================================\n");
		
		//찾을 때 단축키 : Crtl + H
		//팩토리얼 구하기
		
		System.out.println(calFac(10));
		
		//재귀함수를 이용한 팩토리얼 구하는 메소드 
		
		System.out.println(recurFac(5));
		
		
		
		
	} //main 끝 
	
	
	
	
	
	static int recurFac(int inputNum) {
		if(inputNum ==1) {
			return 1;
		}
		return inputNum * recurFac(inputNum-1);
		//5를 넣었다면 5-1은 4
		//5 * (recurFac(4)
		//5 * 4 * recurFac(3)
		//5 * 4 * 3 * recurFac(2)
		//5 * 4 * 3 * 2 * recurFac(1)
		// 5 * 4 * 3 * 2 * 1
	}
	
	
	
	//팩토리얼 구하기
	static long calFac(int num) {
		long facResult = 1;
		for (int i = 1; i <=num; i ++) {
			facResult *= i;
	}
		return facResult;
	}
	
	
	
	
	
	static void recursionPrint(int num) {
		if(num > 0) {
		System.out.println(num);
		recursionPrint(num - 1);
		}
	}
	
	
	
	
	
	
	
	
	
	

}
