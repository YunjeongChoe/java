package ch07_array;

import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.Collections;

public class ArrayStudy {

	public static void main(String[] args) {
		
		
		System.out.println("\n-----------------------배열 (Array)----------------------------\n");
		
		String samjang = "삼장";
		String woogong = "오공";
		String saojeong = "사오정";
		String palgye = "저팔계";
		
		//문자(String) 배열
		//배열의 선언 1
		//숫자 [4]는 첨자를 의미하며, 배열의 크기(4)를 의미한다 
		String[] seoyugi = new String[4];
		
		//.length 배열의 크기를 리턴
		System.out.println(seoyugi.length);
		
		//배열 내 요소(element)의 값을 확인
		//인덱스 사용 (= 인덱싱)
		System.out.println(seoyugi[0]);                       //출력 값:null
		
		//크기만 선언된 배열 내에는 기본값이 들어있다.
		//기본값 (Default)
		//참조 타입인 경우 null
		//기본 타입(숫자형, boolean)
		//  ㄴ숫자타입 : 정수는 0, 실수는 0.0
		//  ㄴboolean 타입 : false
		
		int[] numbers = new int[2];
		System.out.println(numbers[1]);                        //출력값 : 0 기본값이 0이기 때문 
		
		
		
		//for문을 이용하여 0부터 array.length 미만까지 순회하면 배열의 모든 요소에 접근이 가능하다.
		
		for(int i = 0; i < seoyugi.length; i++) {
			System.out.println(seoyugi[i]);
		}
		
		
		
		System.out.println("\n-----------------------배열에 값 넣기----------------------------\n");
		
		seoyugi[0]= samjang;
		seoyugi[1]= "손오공";
		
		printArray(seoyugi);                             //출력값 : 삼장, 손오공, null, null
		
		seoyugi[2]= "사오정";
		seoyugi[3]= "저팔계";
		
		printArray(seoyugi);                            //출력값 : 삼장, 손오공, 사오정, 저팔계
		
		//배열의 단점 
		//크기가 고정됨!
		//늘어나지도, 줄어들지도 않는다. = 값이 추가되지 않고 제거도 못한다.

		//빨간줄 에러는 컴파일 에러로, 실행을 안해봐도 이클립스가 캐치해서 오류 파악
		//실행했을 경우 발생하는 에러는 런타임 에러 ex) seoyugi[4] = "크리링";
		
		
		//배열의 장점
		//배열에 담긴 모든 요소들을 한번에 처리할 수 있다.
		for(int i = 0; i < seoyugi.length; i++) {
			seoyugi[i] = "서유기 " + seoyugi[i];
		}
		printArray(seoyugi);                        //출력값: 서유기 삼장, 서유기 손오공, 서유기 사오정, 서유기 저팔계
		
		System.out.println("\n-------------------손오공이면 서유기를 드래곤볼로 바꾸기-------------------------\n");
		//배열 내 특정 요소에 접근하여 처리할 수 있다.
		for(int i = 0; i < seoyugi.length; i ++) {
			if(seoyugi[i].indexOf("손오공") != -1) {
				seoyugi[i] = seoyugi[i].replace("서유기", "드래곤볼");
			}
		}
		printArray(seoyugi); 
		
		
		
		System.out.println("\n-----------------------로또 번호 만들기----------------------------\n");
		int[] intArray = new int[6];
		printArray(intArray);
		
		//배열 안에 랜덤 숫자 넣기
		//로또 번호 넣어주기
		//1~45 사이의 랜덤 정수
		for(int i = 0; i < intArray.length; i++) {
			int randInt = (int) (Math.random() * 45) + 1;
			intArray[i] = randInt;
		}
		printArray(intArray);
	
		
		System.out.println("\n-----------------------배열의 선언2----------------------------\n");
		String[] students = {"송나겸", "남궁혜연", "김달현"};
		
//		String[] studnets = new String[3];          //위에 한 줄이랑 이 네줄이랑 같다 
//		studnets[0] = "송나겸";
//		studnets[0] = "남궁혜연";
//		studnets[0] = "김달현";
//		printArray(students);
		
		
		
		System.out.println("\n-----------------------문자열 나누기----------------------------\n");
		
		String myInfo = "정찬웅, 010-7398-7332, akow@gmail.com";
		
		// .split (문자열)
		//괄호 안 "문자열을 기준으로" 해당 문자열을 나누어 문자열 배열로 리턴함
		
		String[] infoArray = myInfo.split(", ");
		System.out.println(infoArray.length);                                  //출력값 : 3
		System.out.println(infoArray[0]);                                      //출력값 : 정찬웅
		System.out.println(infoArray[1]);                                      //출력값 : 010453ㅂ4
		System.out.println(infoArray[2]);                                      //출력값 : fd@ddf
		
		// 데이터가 엉망일 때 ","로 일단 나눈 이후 양쪽 공백을 제거해준다.
		for(int i = 0; i < infoArray.length; i++) {
			infoArray[i] = infoArray[i].trim();
			
		}
		printArray(infoArray);
		
		
		
		
		System.out.println("\n-----------------------문자열 나누기----------------------------\n");
		
		String calStr = "1+4+2";
		String[] calArray = calStr.split("\\+");
		//regex란 정규표현식(Regular Expression)의 약자
		//*, ?, + 의 경우 정규표현식에서 특정 의미를 가지는 특수문자이므로 일반 문자로 쓰기위해서 
		//해당 특수문자 앞에 \\를 붙인다.
		printArray(calArray);
		
		//정규표현식 사용 예
		//-연락처를 숫자만 기입했는지 체크
		//-비밀번호에 알파벳 소문자, 대문자, 숫자, 특수기호 최소 1개 이상 넣었는지 체크
		
		
		
		
		System.out.println("\n-----------------------배열의 복사----------------------------\n");
		String[] sinSeoyugi = seoyugi;
		printArray(seoyugi);               //서유기 삼장, 드래곤볼 손오공, 서유기 사오정, 서유기 저팔계
		printArray(sinSeoyugi);            //서유기 삼장, 드래곤볼 손오공, 서유기 사오정, 서유기 저팔계
		
		
		sinSeoyugi[0] = "이승기";
		sinSeoyugi[1] = "이수근";
		printArray(seoyugi);              //이승기, 이수근, 서유기 사오정, 서유기 저팔계
		printArray(sinSeoyugi);           //이승기, 이수근, 서유기 사오정, 서유기 저팔계
		
		//@ 뒤에 붙은건 hashCode를 16진수로 나타낸 것
		System.out.println(seoyugi);
		System.out.println(seoyugi.hashCode());
		
		System.out.println(sinSeoyugi);
		System.out.println(sinSeoyugi.hashCode());
		System.out.println(Integer.toHexString(seoyugi.hashCode()));
		
		System.out.println("\n-----------------------해쉬코드/암호화,복호화----------------------------\n");
		//해쉬코드 (hashcode)
		//객체의 메모리 주소값을 이용해서 해쉬를 적용한 코드
		
		//해쉬(hash)란?
		//해쉬함수(암호화 알고리즘)를 이용해서 데이터를 암호화하는 기법(RSA, SHA, ...)
		
		//암호화. 복호화
		//암호화
		Encoder base64Encoder = Base64.getEncoder();
		String password = "1q2w3e4";
		//문자열을 Byte배열로 변환
		byte[] passByte = password.getBytes();
		String encryption = new String(base64Encoder.encode(passByte));
		System.out.println(encryption);
		//복호화 
		Decoder base64Decoder = Base64.getDecoder();
		String decryption = new String(base64Decoder.decode(encryption));
		System.out.println(decryption);
		
		//암호화시 사용된 알고리즘(여기선 base64)과 일치하는 알고리즘을 이용하여 복호화 해야한다는 것에만 주의 
		
		
		
		
		System.out.println("\n-----------------------올바른 배열의 복사----------------------------\n");
		String[] sinSeoyugi2 = seoyugi.clone();
		sinSeoyugi2[0] = "안재현";
		
		printArray(seoyugi);                            //이승기, 이수근, 서유기 사오정, 서유기 저팔계
		printArray(sinSeoyugi2);                        //안재현, 이수근, 서유기 사오정, 서유기 저팔계
		
		
		// .clone입력을 안했을 때
		String[] sinSeoyugi3 = new String[seoyugi.length];
		//sinSeoyugi3의 각각의 요소에 seoyugi 각각의 요소를 넣으면 됨 
		for(int i=0; i < seoyugi.length; i++ ) {
			sinSeoyugi3[i] = seoyugi[i];
		}
		printArray(sinSeoyugi3);                         //이승기, 이수근, 서유기 사오정, 서유기 저팔계
		
		
		
		
		
		
		
		System.out.println("\n-----------------------숫자 배열----------------------------\n");
		//인덱스 0번과 1번 값의 위치를 바꾸기 
		int[] numArray = {18, 22, 123, 43, 391, 3, 31};
		
		int temp = numArray[0];
		numArray[0] = numArray[1];
		numArray[1] = temp;
		printArray(numArray);
		
		
		//인덱스 2번 값과 인덱스 3번값의 위치를 바꾸기. 추가적인 변수 선언 없이.
		//(숫자형 배열에서만 가능한 방법)
		
		//123+43
		numArray[2] = numArray[2] + numArray[3];
		//123 + 43 - 43
		numArray[3] = numArray[2] - numArray[3];
		//123 + 43 - 123
		numArray[2] = numArray[2] - numArray[3];
		
		
		System.out.println("\n------------------------정렬(알고리즘)---------------------------\n");
		
		//버블 정렬
		for(int i = 0; i < numArray.length-1; i++) {         //-1 하는 이유 : 루핑할때마다 뒤에서부터 정렬되기 때문에 배열의 크기가 점점 줄어들어서
			if(numArray[i] > numArray[i+1]) {
				int tmp = numArray[i];
				numArray[i] = numArray[i+1];
				numArray[i+1] = tmp;
			}
		}
		printArray(numArray);
		
		//오름차순 정렬  i > i+1 
		for(int j = 0; j < numArray.length; j++) {
			for(int i = 0; i < numArray.length-1; i++) {
				if(numArray[i] > numArray[i+1]) {
					int tmp = numArray[i];
					numArray[i] = numArray[i+1];
					numArray[i+1] = tmp;
				}
			}
		}printArray(numArray);
		
		
		
		//내림차순 정렬 i < i+1
		for(int j = 0; j < numArray.length; j++) {
			for(int i = 0; i < numArray.length-1; i++) {
				if(numArray[i] < numArray[i+1]) {
					int tmp = numArray[i];
					numArray[i] = numArray[i+1];
					numArray[i+1] = tmp;
				}
			}
		}printArray(numArray);
		
		
		//for문 반복 횟수 줄이기  numArray.length-1-j
		for(int j = 0; j < numArray.length; j++) {
			for(int i = 0; i < numArray.length-1-j; i++) {
				if(numArray[i] < numArray[i+1]) {
					int tmp = numArray[i];
					numArray[i] = numArray[i+1];
					numArray[i+1] = tmp;
				}
			}
		}printArray(numArray);
		
		
		
		System.out.println("\n------------------------정렬---------------------------\n");
		
		//오름차순 쉽게 하기
		Arrays.sort(numArray);
		printArray(numArray);
		
		//내림차순 쉽게 하기
//		Arrays.sort(numArray, Collections.reverseOrder());     //실행안됨
		//위 방법은 객체를 담은 배열일 경우에만 가능한 방법 (기본형인 int 배열이 아니라 참조타입인 Integer 배열은 가능)
		Integer[] integerArr = {34, 67, 573, 1, 45, 12};
		Arrays.sort(integerArr, Collections.reverseOrder());
		
		//오름차순을 이용한 내림차순
		//1. numArray의 모든 요소에 -1 곱하기
		//2. Arrays.sort(numArray)로 오름차순 정렬
		//3. numArray의 모든 요소에 -1 곱하기
		
		for(int i = 0; i < numArray.length; i++) {
			numArray[i] *= -1;
		}
		
		Arrays.sort(numArray);

		for(int i = 0; i < numArray.length; i++) {
			numArray[i] *= -1;
		}
		
		printArray(numArray);
		
		
		System.out.println("\n------------------------다차원 배열---------------------------\n");
		
		int[][] doubleArr = {{1,2,3}, {4,5,6}, {7,8,9}};
		int[] tempArr = doubleArr[0];
		printArray(tempArr);
		
		System.out.println(doubleArr[2][1]);
		
		int[][][] tripleArr = {{{1,2,3}, {4,5,6}, {7,8,9}}, {{10,20,30}, {40,50,60}, {70,80,90}}, {{100,200,300}, {400,500,600}, {700,800,900}}};
		
		//80꺼내기
		System.out.println(tripleArr[1][2][1]);
		
		
		
		System.out.println("\n-------------------------------------------------\n");
		String[] nameArray = {"한예성", "김달현", "송나겸", "김성윤", "남궁혜연",
							"오혁진", "최윤정", "박승주", "석승원", "김성빈", "신윤빈",
							"염현섭", "박기현", "유동준", "이한정", "임동성", "임성헌",
							"정기준", "박설리", "가나혜", "황의창"};
		//for문을 이용해서 "박"씨 성을 가진 동기가 몇 명인지 출력 
		//각각의 요소에 접근해서 앞글자가 "박"인지 확인 후 "박"이면 카운팅 
		int count = 0;
		for(int i = 0; i < nameArray.length; i++) {
		if(nameArray[i].substring(0,1).equals("박")) {
			count++;
			}
		}
		System.out.println("박씨 성은 총 " + count + "명 입니다.");
		
		
		
		
		System.out.println("\n-------------------------------------------------\n");
		
		int[] numArr = {2, 342, 66, 15, 165, 34, 176};
		//numArr의 최댓값, 최솟값을 출력
		int minVal = numArr[0];
		int maxVal = numArr[0];
		//for문을 돌며, 각각의 요소가 현재의 minVal보다 작다면 minVal에 해당 요소를 담음
		//현재의 maxVal 보다 크다면 maxVal에 해당 요소를 담
		for(int i = 0; i < numArr.length; i++) {
			if(numArr[i] < minVal) {
				minVal = numArr[i];
			}if(numArr[i] > maxVal) {
				maxVal = numArr[i];
			}
		}System.out.println("최솟값은 " + minVal + "입니다.");
		System.out.println("최댓값은 " + maxVal + "입니다.");
		
		
		
		System.out.println("\n-------------------------------------------------\n");
		
		//숫자형 배열의 최댓값을 구하는 로직을 함수로 만들기
		int[] temArray = {234, 212, 12, 8, 56, 910};
		//동적 매개변수(파라미터) 받는 메소드 
		maxVal = maxValue(45, 676, 23, 94, 34, 57);
		System.out.println(maxVal);
		
		
		
		
		System.out.println("\n-------------------------------------------------\n");
		//로또 번호 만들기
		//Array배열에 랜덤 숫자(1~45)를 6개 넣어주기(중복없이)
		
		int[] lottoArray = new int[6];
		//반복문이 돌면서 매번 randInt를 생성하고
		//먼저 lottoArray에 해당 randInt가 존재하는지 파악한 후, 존재하지 않으면 추가 존재하면 패스 
		int idx = 0;
		while(idx < 6) {
			int randInt = (int) (Math.random() * 45) + 1;
			boolean isDuple = false;   //중복이 안될 때 
			
			//중복체크 (중복되면 isDuple은 true
			for(int i = 0; i < lottoArray.length; i++) {
				if(lottoArray[i] == randInt) {
					isDuple = true;
				}
			}
			
			if(isDuple == false) {
				lottoArray[idx] = randInt;
				idx++;				
			}
		}
		printArray(lottoArray);
		
		
		
		
		
		
		
		
		
		
		

	}//main 끝 

	
	
	
	
	
	static int maxValue(int... anyArray) {
		int result = anyArray[0];
		for(int i = 0; i < anyArray.length; i++) {
			if(anyArray[i] > result) {
				result = anyArray[i];
			} 
		}return result;
}
	
	
	
	
	
	
	
	

	
	
	
	
	static void printArray(int[] intArray) {
		for(int i = 0; i < intArray.length; i++) {
			if(i == intArray.length -1) {                           
				System.out.println(intArray[i]);
			}else {				
				System.out.print(intArray[i] + ", ");              
			}
		}
	}
		
	
	
	
	
	
	
	
	
	
	static void printArray(String[] strArray) {
		for(int i = 0; i < strArray.length; i++) {
			if(i == strArray.length -1) {                          //마지막에 붙는 , 빼기  
				System.out.println(strArray[i]);
			}else {				
				System.out.print(strArray[i] + ", ");              //출력값 : 삼장, 손오공, null, null,
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
