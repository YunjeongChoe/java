package ch10_extends_interface.rpg;

public class Enemy extends Character {

	public Enemy() {
		super();
	}

	public Enemy(String name, int damage, int hp) {
		super(name, damage, hp);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
