package ch10_extends_interface.lol;

public class Champion {
	String name;
	int damage;
	int hp;

}
