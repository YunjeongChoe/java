package ch10_extends_interface.lol;

public interface VoiceInterface {
	public void ctrl1();
	public void ctrl2();
	public void ctrl3();
	public void ctrl4();
	
	

}
