package ch08_collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CollectionMap {

	public static void main(String[] args) {
		
		System.out.println("\n=======================맵(Map)의 선언======================\n");
		HashMap<String, String> stuMap = new HashMap<String, String>();
		HashMap<String, Integer> coinMap = new HashMap<>();
		//다형성
		Map<Integer, String> stuMap2 = new HashMap<Integer, String>();
		
		System.out.println("\n---------------------.put(key, value)-------------\n");
		//맵에 데이터 추가 
		stuMap.put("첫쨰", "성빈");
		stuMap.put("둘째", "달현");
		stuMap.put("셋째", "현섭");
		//맵은 중복된 키를 허용하지 않음 ( 순서 보장 X)
		//중복된 키를 추가하게 되면 기존 키에 값을 덮어쓴다.
		System.out.println(stuMap);
		
		
		coinMap.put("비트코인", 50_000_000);
		coinMap.put("이더리움", 3_700_000);
		System.out.println(coinMap);
		
		stuMap2.put(0, "윤정");
		stuMap2.put(1, "나혜");
		stuMap2.put(2, "승주");
		System.out.println(stuMap2);
		
		
		System.out.println("\n---------------------.get(key)--------------------\n");
		//key에 해당하는 value를 리턴
		System.out.println(stuMap.get("첫째"));
		//없는 key를 넣으면 null을 리턴
		
		System.out.println(coinMap.get("비트코인"));
		System.out.println(stuMap2.get(1));
		
		
		System.out.println("\n---------------------.size()-------------\n");
		//맵 안에 데이터의 개수 리턴
		System.out.println(stuMap.size());
		
		System.out.println("\n---------------------.containsKey(값)-------------\n");
		//맵 안에 있는 key중의 값에 해당하는게 있으면 true, 없으면 false 리턴
		System.out.println(stuMap.containsKey("둘째"));
		
		
		System.out.println("\n---------------------.containsValue()-------------\n");
		//맵 안에 있는 값(value)중 괄호 안의 값에 해당하는게 있으면 true, 없으면 false 리턴
		System.out.println(stuMap2.containsValue("나혜"));
		System.out.println(stuMap2.containsValue("나"));
		
		
		System.out.println("\n---------------------.remove(key)-------------\n");
		//key에 해당하는 데이터를 삭제
		coinMap.remove("비트코인");
		System.out.println(coinMap);
		
		
		System.out.println("\n=============================Map 순회================================\n");
		//1. keySet 이용
		Set<String> keySet = stuMap.keySet();
		
		//set을 향상된 for문으로 순회
		for(String key : keySet) {
			System.out.println(key + " : " + stuMap.get(key));
			
		}
		
		
		Set<Integer> keySet2 = stuMap2.keySet();
		for(int num : keySet2) {                                        //오토 박싱, 언박싱 돼서 Integer라고 안써도 됨
			System.out.println(num + " : " + stuMap2.get(num));
		}
		
		System.out.println();
		//2. EntrySet 이용
		Set<Entry<String, String>> entrySet = stuMap.entrySet();
		for(Entry<String, String> entry : entrySet) {
			String key = entry.getKey();
			String value = entry.getValue();
			System.out.println(key + " : " + value);
		}
		System.out.println();
		Set<Entry<Integer, String>> entrySet2 = stuMap2.entrySet();
		for(Entry<Integer, String> entry : entrySet2) {
			Integer key = entry.getKey();
			String value = entry.getValue();
			System.out.println(key + " : " + value);
		}
		
		
		System.out.println("\n----------------------forEach문----------------------\n");
		stuMap.forEach((key, value) -> System.out.println(key + " : " + value));
		
		
		
		
		
		
		
		
	}

}
