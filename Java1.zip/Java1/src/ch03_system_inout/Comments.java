package ch03_system_inout;

public class Comments {
	
	
	/**
	 * 과일 
	 * 
	 */
	static String strawberry = "딸기";
	
	
	

	public static void main(String[] args) {
		
		//주석(Comment)
		
		//단일 주석 (코드 앞에 //)
		//단축키 [컨트롤 + /]
		/* 
		 *다중 주석 
		 *작성자 : 최윤정
		 *작성일: 2022-04-13
		 **/
		
		//자바 문서 (javadoc)주석
		/**
		 * 으아아아
		 * 선언문위에 다는 주석 
		 */
		System.out.println(strawberry);
		
		
		//TODO 주석
		//개발 중에 구현해야 할 부분에 대해 미리 작성을 해놓는 경우에 이용함
		
		// TODO 딸기를 콘솔창에 출력해야 함
		System.out.println(strawberry);
		
		
		
		
		
		
	}

}
