package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.UsersVO;

public class UsersDao {
	
	private static UsersDao instance = new UsersDao();
	
	public static UsersDao getInstance() {
		return instance;
	}
	
	private UsersDao() {
		
	}
	
	//회원가입
	public int registUser(Connection conn, UsersVO user) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO			");
		query.append("		  users			");
		query.append("VALUES	(			");
		query.append("		  ?				");
		query.append("		, ?	 			");
		query.append("		, ?	 			");
		query.append("		, ?	 			");
		query.append("		, ?	 			");
		query.append("		)				");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setString(idx++, user.getUserId());
		ps.setString(idx++, user.getUserPassword());
		ps.setString(idx++, user.getUserName());
		ps.setString(idx++, user.getUserGender());
		ps.setInt(idx++, user.getUserScore());
		
		int cnt = ps.executeUpdate();
		if (ps != null)ps.close();

		return cnt;
	}
	
	
	//로그인
	public UsersVO loginUser(Connection conn, String id) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		  user_id			");
		query.append("		, user_password		");
		query.append("		, user_name			");
		query.append("FROM						");
		query.append("		users				");
		query.append("WHERE 1=1					");
		query.append("	AND user_id = ?			");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());

		int idx = 1;
		ps.setString(idx++, id);

		ResultSet rs = ps.executeQuery();

		UsersVO result = new UsersVO();

		while (rs.next()) {
			result.setUserId(rs.getString("user_id"));
			result.setUserPassword(rs.getString("user_password"));
			result.setUserName(rs.getString("user_name"));
		}

		if (ps != null)ps.close();
		if (rs != null)rs.close();

		return result;
		
		
	}
	
	// 목록 조회 (SELECT)
		public ArrayList<UsersVO> getUserList(Connection conn) throws SQLException {
			StringBuffer query = new StringBuffer();
			query.append("SELECT						");
			query.append("		  user_name				");
			query.append("		, user_gender			");
			query.append("		, user_score	 		");
			query.append("FROM							");
			query.append("		users					");
			query.append("ORDER BY user_score DESC 		");

			PreparedStatement ps = conn.prepareStatement(query.toString());
			// 쿼리문에서 스트링 객체만 빼옴

			// 4. 쿼리문 실행과 동시에 결과를 ResultSet 객체에 담는다.
			ResultSet rs = ps.executeQuery();

			ArrayList<UsersVO> result = new ArrayList<>();

			// 5. 실행결과인 rs를 이용하여 데이터조회
			while (rs.next()) {
				UsersVO temp = new UsersVO();

				temp.setUserName(rs.getString("user_name"));;
				temp.setUserGender(rs.getString("user_gender"));
				temp.setUserScore(rs.getInt("user_score"));

				result.add(temp);
			}

			if (ps != null)
				ps.close();
			if (rs != null)
				rs.close();

			return result;

		}
	
	
	
	
	
	// 중복체크용
	public boolean dupleCheck(Connection conn, String id) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT					");
		query.append("		  COUNT(*) AS cnt	");
		query.append("FROM						");
		query.append("		users				");
		query.append("WHERE 1=1					");
		query.append("	AND	user_id = ?			");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		ps.setString(idx++, id);
		
		ResultSet rs = ps.executeQuery();
		int cnt = 0;
		
		while(rs.next()) {
			cnt = rs.getInt("cnt");
		}
		
		if(ps != null) ps.close();
		if(rs != null) rs.close();
		
		return (cnt == 1);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// 점수 (UPDATE)
		public int updateSco(Connection conn, UsersVO user) throws SQLException {
			StringBuffer query = new StringBuffer();
			query.append("UPDATE						");
			query.append("		  users				");
			query.append("SET							");
			query.append("		user_id = ?			");
			query.append("	,	user_password = ?		");
			query.append("	,	user_name = ?			");
			query.append("	,	user_gender = ?			");
			query.append("	,	user_score = ?			");
			query.append("WHERE	1=1						");
			query.append("	AND	user_id = ?				");

			PreparedStatement ps = conn.prepareStatement(query.toString());

			int idx = 1;
			ps.setString(idx++, user.getUserId());
			ps.setString(idx++, user.getUserPassword());
			ps.setString(idx++, user.getUserName());
			ps.setString(idx++, user.getUserGender());
			ps.setInt(idx++, user.getUserScore());
			ps.setString(idx++, user.getUserId());

			int cnt = ps.executeUpdate();
			if (ps != null)
				ps.close();

			return cnt;

		}
	
	
	
	
	
	
	
}
