package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.ResultVO;
import model.UsersVO;
import service.ResultService;
import service.UsersService;

public class MyProjMain {

	public static void main(String[] args) {

		UsersService userService = UsersService.getInstance();

		Scanner sc = new Scanner(System.in);
		
		System.out.println(" _______  ___      ___   __    _  ______     ______   _______  _______  _______ \n"
				+ "|  _    ||   |    |   | |  |  | ||      |   |      | |   _   ||       ||       |\n"
				+ "| |_|   ||   |    |   | |   |_| ||  _    |  |  _    ||  |_|  ||_     _||    ___|\n"
				+ "|       ||   |    |   | |       || | |   |  | | |   ||       |  |   |  |   |___ \n"
				+ "|  _   | |   |___ |   | |  _    || |_|   |  | |_|   ||       |  |   |  |    ___|\n"
				+ "| |_|   ||       ||   | | | |   ||       |  |       ||   _   |  |   |  |   |___ \n"
				+ "|_______||_______||___| |_|  |__||______|   |______| |__| |__|  |___|  |_______|");
		
		
		while (true) {
			System.out.println("행동을 선택해주세요.");
			System.out.println("1. 회원가입 | 2. 로그인 | 3. 종료");
			System.out.print(">>> ");

			int command = 0;
			try {
				command = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("숫자만 입력해주세요");
				continue;
			}

			if (command == 1) {
				// 회원가입
				System.out.print("아이디를 입력해주세요: ");
				String id = sc.nextLine();
				System.out.print("비밀번호를 입력해주세요: ");
				String pw = sc.nextLine();
				System.out.print("이름을 입력해주세요: ");
				String nm = sc.nextLine();
				System.out.print("성별을 입력해주세요: ");
				String gd = sc.nextLine();

				// 중복체크
				boolean isDuple = userService.dupleCheck(id);

				if (isDuple) {
					System.out.println("중복된 아이디 입니다.");
				} else {
					// 회원가입 진행
					int cnt = userService.registUser(new UsersVO(id, pw, nm, gd, 0));

					if (cnt > 0) {
						System.out.println("회원가입이 성공적으로 이루어졌습니다.");
					} else {
						System.out.println("회원가입 실패");
					}
				}

			} else if (command == 2) {
				// 로그인
				System.out.print("아이디: ");
				String id = sc.nextLine();
				System.out.print("비밀번호: ");
				String pw = sc.nextLine();

				UsersVO login = userService.loginUser(id);

				if (pw.equals(login.getUserPassword())) {

					System.out.println(login.getUserName() + "님 환영합니다.");
					

					
					// 로그인 성공
					while (true) {
						System.out.println("1. 시작하기 | 2. 랭킹보기 | 3. 종료하기");

						int num = Integer.parseInt(sc.nextLine());

						if (num == 1) {
							// 시작하기
							System.out.println("아무것도 가진 게 없는 나...\n사랑만은 가지고 싶다...\n사랑은.. 쟁취하는거랬어... \n진정한 사랑을 찾고 말거야..!");
							System.out.println("\n" + 
									"。+。\t ☆  ゜。+  。☆　。 \t＊゜+  ゜。 *。" +
									" .___                 .        .                         \n" + 
									" /   \\   ___    ___   |        /       __.  _   __   ___ \n" + 
									" |__-' .'   `  /   `  |        |     .'   \\ |   /  .'   `\n" + 
									" |  \\  |----' |    |  |        |     |    | `  /   |----'\n" + 
									" /   \\ `.___, `.__/| /\\__      /---/  `._.'  \\/    `.___,\n" + 
									"                                                         \n" + 
									"");
							try {
								Thread.sleep(3000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							} 
							System.out.println("======================================================");
							System.out.println("\t\t\t첫만남\t\t\t");
							System.out.println("======================================================\n");
							System.out.print("상대방 : 안녕하세요! 민식이 소개로 나오신분 맞으시죠? 죄송해요. 제가 좀 늦었죠..\n\t 커피는 제가 사겠습니다!\n"
									+ "↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
									+ "1. 웃으면서 괜찮다고 한 뒤 비싼 커피를 얻어 먹는다. | 2. (언짢은 표정으로) 괜찮다고 한 뒤 내가 산다. >>>");
							

							int firstMet = Integer.parseInt(sc.nextLine());
							

							if (firstMet == 1) {
								// 커피 얻어먹기
								login.setUserScore(login.getUserScore()+10);
								System.out.println("나    : 하하 괜찮아요! 늦을 수도 있죠. 그럼 저 주문할게요. 저는 벤티사이즈 제주 유기농 말차로 만든"
										+ "\n\t 크림 프라푸치노에 샷추가하고 무지방우유로 바꿔주시고 통자바칩 추가할게요.\n\t"
										+ " 그리고 바닐라시럽 추가하고 얼음은 적게 넣어주세요. 드리즐도 많이 추가해주시고\n\t 휘핑크림 많이 올려주세요. 아, 덜 차갑게 해주세요!");
								try {
									Thread.sleep(5000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.println("상대방 : (흠.. 커피가 10300원..? 야무지게 휘핑크림까지 추가했네..)\n\t 하하 뭘 많이 추가해서 드시네요.. 전 라떼주세요."
										+ "\n\t 오늘 날씨도 좋은데 커피 다 마시고 저녁 먹기전에 산책하는게 어때요?\n\t 혹시 생각해 놓은 곳 있으세요?\n");

							} else if (firstMet == 2) {
								// 더치페이
								login.setUserScore(login.getUserScore()+15);
								System.out.println("상대방 : (표정이 왜저래? 괜찮다는거야 안괜찮다는거야..찜찜하군.)\n\t 오늘 날씨도 좋은데 커피 다 마시고 저녁 먹기전에 산책하는게 어때요?"
										+ "\n\t 혹시 생각해 놓은 곳 있으세요?\n");

								try {
								Thread.sleep(3000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							} 
							}

							System.out.print("↓↓↓↓↓나의 대답은?↓↓↓↓↓\n"
									+ "1. 산책말고 낮술 어떠세요? | 2. 지압발판 산책로 어떠세요? >>>");

							int drinkWalk = Integer.parseInt(sc.nextLine());
							

							if (drinkWalk == 1) {
								//낮술
								login.setUserScore(login.getUserScore()+4);
								System.out.println("상대방 : (에바야.. 대낮부터 무슨 술이야...)\n\t 하하 이 시간에 술은 좀 그렇고.. 그럼 여기서 얘기를 조금 더 나누죠 뭐!\n"
										+ "나     : 그럴까요? 아 사실 제가 준비한 작은 선물이 있어요.\n"
										+ "상대방 : 정말요? 전 아무것도 준비를 못했는데..\n"
										+ "나     : 잠시만요...!!\n");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓내가 준비한 선물은?↓↓↓↓↓\n"
										+ "1. 책갈피 | 2.향수 >>>");
								
								int gift = Integer.parseInt(sc.nextLine());
								
								if(gift == 1) {
									//책갈피
									login.setUserScore(login.getUserScore()+21);
									System.out.println("나     : 제가 직접 찾은 네잎클로버로 만든 책갈피에요. 행운이 가득할 거예요.\n"
											+ "상대방 : 와~ 제가 마침 책갈피 잃어버려서 사려고 했는데 감사합니다!\n\t정말 잘 쓸게요!");
								}else if (gift ==2 ) {
									//향수 
									login.setUserScore(login.getUserScore()+9);
									System.out.println("나     : 어떤 향을 좋아하실지 몰라서 직원한테 추천받아서 샀어요.\n"
											+ "상대방 : (첫만남부터 웬 향수? 부담스러워.. 하필 내가 또 싫어하는 향이잖아..)\n\t..감사합니다....잘 쓸게요");
								}
								System.out.println("        그나저나 " + login.getUserName() +"씨는 취미 생활이 뭐예요?\n"
										+ "나     : 제 취미생활은..\n");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓나의 대답은?↓↓↓↓↓\n"
										+ "1. 고대유물 발굴이요 | 2. 비둘기한테 먹이주는거요 | 3. 등산 좋아합니다 >>>");
								
								int hobby = Integer.parseInt(sc.nextLine());
								
								if(hobby == 1) {
									//고대유물발굴
									login.setUserScore(login.getUserScore()+16);
									System.out.println("상대방 : 네????\n"
											+ "나     : 하하 농담이고 오래된 책 찾아서 읽는게 취미에요.\n"
											+ "상대방 : 멋있어요. 저랑 취미가 비슷하시네요!");
								}else if(hobby == 2) {
									//비둘기
									login.setUserScore(login.getUserScore()+4);
									System.out.println("상대방 : 네????\n"
											+ "나     : 촤하핫!! 농담입니다~~ \n"
											+ "상대방 : 하하 진짠 줄 알았어요..");
									
								}else if(hobby == 3) {
									//등산
									login.setUserScore(login.getUserScore()+10);
									System.out.println("나    : 어제도 다녀왔어요. 등산 좋아하시면 같이 가요!\n"
											+ "상대방 : 부지런하시네요! 등산은 생각 좀 해볼게요..하하하");
								}
								
								System.out.println("        그나저나 저희 저녁은 어디서 먹어요? 민식이 말로는 정해오신다고 하셔서...\n"
										+ "나     : 그럴까요? 제가 생각해 온 맛집이 있는데 그쪽으로 가시죠!\n");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓내가 정해온 저녁 메뉴는?↓↓↓↓↓\n"
										+ "1. 대하구이 | 2. 자반고등어 >>>");
									int fish = Integer.parseInt(sc.nextLine());
									if(fish == 1) {
										//대하구이
										login.setUserScore(login.getUserScore()+10);
										System.out.println("나     : 제가 대하구이 진짜 맛있게 잘 하는 집 알아요!\n"
												+"상대방 : 대하구이 좋죠! 가보자고~!");
										for(int i = 0; i <1; i++) {
											System.out.println("-------------------");
											try {
												Thread.sleep(2000);
											} catch (InterruptedException e) {
												e.printStackTrace();
											}
											System.out.println("★☆식당 도착!☆★");
											System.out.println("-------------------\n");
											
											System.out.println("대하구이를 시킨 당신과 상대방.\n"
													+ "새우가 노릇노릇 잘 익어가고있다.\n\n"
													+ "다음으로 내가 할 말은...?");
											try {
												Thread.sleep(3000);
											} catch (InterruptedException e) {
												e.printStackTrace();
											} 
											System.out.print("↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
													+ "1. 까준다. | 2. 까달라고 한다. >>>");
											
											int prawn = Integer.parseInt(sc.nextLine());
											if(prawn == 1) {
												//까준다
												System.out.println("나     : 제가 껍질 까드릴게요!\n"
														+ "나는 상대방에게 맨 손으로 새우껍질을 까주었다.\n"
														+ "역시 새우는 맨 손으로 까야 제 맛이지!!"
														+ "상대방 : (뭐야.. 위생뭐야...) 앗 저 잠깐 화장실 좀 다녀올게요!");
												for(int j = 0; j <5; j++) {
													System.out.println("..............................");
													try {
														Thread.sleep(800);
													} catch (InterruptedException e) {
														e.printStackTrace();
													}
												}
												System.out.println("5분이 지나도 10분이 지나도 상대방은 돌아오지 않았다.\n당신의 위생관념에 상대방은 탈주하였다!"
														+ "\n소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
													userService.updateSco(login);
													System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
													break;
											}else if(prawn == 2) {
												//까달라고
												System.out.println("나    : 저 새우 좀 까주세요~~~\n"
														+ "상대방 : (살짝 당황스럽다) 네...? 네..\n\n"
														+ "상대방이 나를 위해 새우를 까주고 있다.. 그런데..\n"
														+ "맨 손으로 까주고 있다...!!!!!!!!!\n"
														+ "상대방의 위생관념에 놀란 나는 화장실을 간다고 한 뒤 도망나왔다.");
												userService.updateSco(login);
												System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
												break;
											}
											
										}
										
										
										
										
										
									}
									if(fish == 2) {
										//고등어
										login.setUserScore(login.getUserScore()+10);
										System.out.println("나     : 이 근처에 자반고등어 백반 잘 나오는 곳이 있거든요? 정말 맛있어요. 가시죠!\n"
												+ "상대방 : 고등어 비린내 나고 좋죠! 반찬이 기대가 되네요.\n\t 빨리 가요!\n");
										for(int i = 0; i <1; i++) {
											System.out.println("-------------------");
											try {
												Thread.sleep(2000);
											} catch (InterruptedException e) {
												e.printStackTrace();
											}
											System.out.println("★☆식당 도착!☆★");
											System.out.println("-------------------\n");
										}
										System.out.println("식당에 도착해 식사를 하려는데 상대방이 생선 가시를 잘 못바른다.\n"
												+ "나는 생선가시를 발라 줄 것인가?");
										try {
											Thread.sleep(3000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
											System.out.print("↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
													+ "1. 가시를 발라준다. | 2. 신경쓰지 않는다. >>>");
											int fishbone = Integer.parseInt(sc.nextLine());
											if(fishbone == 1) {
												//가시 발라줌
												login.setUserScore(login.getUserScore()+0);
												System.out.println("나    : 제가 가시를 발라드릴게요!\n\n"
														+ "하지만 젓가락질이 서툰 당신.. 고등어를 완전히 헤집어 놨다!\n상대방의 표정이 안좋아진다.\n\n"
														+ "상대방 : 저 잠깐 화장실 좀 다녀올게요...!!");
												for(int i = 0; i <5; i++) {
													System.out.println("..............................");
													try {
														Thread.sleep(800);
													} catch (InterruptedException e) {
														e.printStackTrace();
													}
												}
												System.out.println("5분이 지나도 10분이 지나도 상대방은 돌아오지 않았다.\n당신의 센스없는 선택에 상대방은 탈주하였다!"
														+ "\n소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
													
													userService.updateSco(login);
													System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
													break;
											}else if(fishbone == 2) {
												//노신경
												login.setUserScore(login.getUserScore()+0);
												System.out.println("나    : 젓가락질 잘해야만 밥을 먹나요..♪\n"
														+ "상대방 : (약올리는거야 뭐야..? 짜증나..)\n"
														+ "상대방 : 저 잠깐 화장실 좀 다녀올게요...!!");
												for(int i = 0; i <5; i++) {
													System.out.println("..............................");
													try {
														Thread.sleep(800);
													} catch (InterruptedException e) {
														e.printStackTrace();
													}
												}
												System.out.println("5분이 지나도 10분이 지나도 상대방은 돌아오지 않았다.\n당신의 센스없는 선택에 상대방은 탈주하였다!"
														+ "\n소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
													
													userService.updateSco(login);
													System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
													break;
											}
									}
									
									

							} else if (drinkWalk == 2) {
								//산책
								login.setUserScore(login.getUserScore()+11);
								System.out.println("상대방 : 좋아요! 지압하면 혈액순환도 되고 좋을것 같아요.\n");
								for(int i = 0; i <1; i++) {
									System.out.println("-------------------");
									try {
										Thread.sleep(1000);
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
									System.out.println("★☆산책로 도착!☆★");
									System.out.println("-------------------\n");
								}
								
								System.out.println("상대방 : 지압발판이 너무 시원하네요.. 여기에 가끔 와야겠어요.\n\t 그나저나 " + login.getUserName() +"씨는 취미 생활이 뭐예요?\n"
										+ "나     : 제 취미생활은..\n");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓나의 대답은?↓↓↓↓↓\n"
										+ "1. 고대유물 발굴이요 | 2. 비둘기한테 먹이주는거요 | 3. 등산 좋아합니다 >>>");
								
								int hobby = Integer.parseInt(sc.nextLine());
								if(hobby == 1) {
									//고대유물발굴
									login.setUserScore(login.getUserScore()+16);
									System.out.println("상대방 : 네????\n"
											+ "나     : 하하 농담이고 오래된 책 찾아서 읽는게 취미에요.\n"
											+ "상대방 : 멋있어요. 저랑 취미가 비슷하시네요!");
								}else if(hobby == 2) {
									//비둘기
									login.setUserScore(login.getUserScore()+4);
									System.out.println("상대방 : 네????\n"
											+ "나     : 촤하핫!! 농담입니다~~ \n"
											+ "상대방 : 하하 진짠 줄 알았어요..");
									
								}else if(hobby == 3) {
									//등산
									login.setUserScore(login.getUserScore()+10);
									System.out.println("나    : 어제도 다녀왔어요. 등산 좋아하시면 같이 가요!\n"
											+ "상대방 : 부지런하시네요! 등산은 생각 좀 해볼게요..하하하");
								}
								System.out.println("        근데 지압발판 산책로 정말 특이하고 좋네요. 이런 덴 처음 와봤어요.\n"
										+ "나     : 그런가요? 가끔 오면 건강해지는 것 같더라고요. 하하핫\n"
										+ "앗..! 걷다가 상대방의 어깨를 보니 사마귀가 앉아있다.\n나도 사마귀 극혐하는데... 어떡하지?\n");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
										+ "1. 키우는거냐고 조심스럽게 물어본다. | 2. 다른사람에게 사마귀 좀 떼어달라고 부탁한다. | 3. 사마귀를 내려친다. >>>");
									
								int insect = Integer.parseInt(sc.nextLine());
									
								if(insect == 1) {
									//애완사마귀
									login.setUserScore(login.getUserScore()+17);
									System.out.println("나    : 저 혹시 어깨에 사마귀 기어다니는데.. 키우시는 거예요..?\n"
											+ "상대방 : 헉 네 맞아요! 얘가 언제 나왔지...?\n잃어버릴 뻔 했네요.. 감사해요!");
								}else if(insect == 2) {
									//부탁하기
									login.setUserScore(login.getUserScore()+0);
									System.out.println("나     : (옆에 지나가던 사람에게)\n"
											+ "저기.. 정말 죄송한데요. 제 친구어깨에 사마귀가 있는데 쟤 좀 떼어내주실 수 있나요?\n "
											+ "(퍽....!!!!!!!!!)\n"
											+ "상대방 : 마귀야!!!! 제 애완사마귀였어요!!!!!\n"
											+ "상대방의 애완 곤충을 죽여버렸다..\n상대방의 애완사마귀를 죽인 당신\n"
											+ "소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!");

									userService.updateSco(login);
									System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
									break;	
								}else if(insect == 3) {
									//내려치기
									login.setUserScore(login.getUserScore()+0);
									System.out.println("나     : 잠깐!!! 움직이지 마세요!!! 어깨에 사마귀가!!!!!\n"
											+ "(퍽....!!!!!!!!!)\n"
											+ "상대방 : 마귀야!!!! 제 애완사마귀였어요!!!!! 죽이시면 어떡해요!!!!!!!!!\n"
											+ "상대방의 애완 곤충을 죽여버렸다..\n상대방의 애완사마귀를 죽인 당신\n"
											+ "소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!");

									userService.updateSco(login);
									System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
									break;	
								}
								
								System.out.println("상대방 : 이제 슬슬 배고파지는데 저녁먹으러 갈까요?\n"
										+ "나     : 그럴까요? 제가 생각해 온 맛집이 있는데 그쪽으로 가시죠!");
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.print("↓↓↓↓↓내가 정해온 저녁 메뉴는?↓↓↓↓↓\n"
										+ "1. 자반고등어 | 2. 웨이팅 복불복인 파스타 맛집 >>>");
								
								int dinner = Integer.parseInt(sc.nextLine());
								
								if(dinner == 1) {
									//고등어
									login.setUserScore(login.getUserScore()+15);
									System.out.println("나     : 이 근처에 자반고등어 백반 잘 나오는 곳이 있거든요? 정말 맛있어요. 가시죠!\n"
											+ "상대방 : 고등어 비린내 나고 좋죠! 반찬이 기대가 되네요.\n\t 빨리 가요!\n");
									for(int i = 0; i <1; i++) {
										System.out.println("-------------------");
										try {
											Thread.sleep(2000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
										System.out.println("★☆식당 도착!☆★");
										System.out.println("-------------------\n");
									}
									System.out.println("식당에 도착하니 만석이다!\n 때마침 식당안에 상대방의 동성친구가 있는걸 상대방이 발견했다!!\n"
											+ "상대방은 친구와 나에게 합석이 괜찮은지를 물어보고 합석을 하게 되었다.\n"
											+ "상대방의 친구가 밑반찬으로 나온 깻잎장아찌를 못떼고 있다.\n나는 깻잎 떼는것을 도와줄 것인가? 못 본 체 할 것인가?");
									try {
										Thread.sleep(3000);
									} catch (InterruptedException e) {
										e.printStackTrace();
									} 
									System.out.println("↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
											+ "1. 도와주고 떼어진 깻잎을 상대방 밥그릇 위에 올려준다. | 2. 모르는 체 한다. >>>");
									
									int sesameLeaf = Integer.parseInt(sc.nextLine());
									
									if(sesameLeaf == 1) {
										//도와준다
										login.setUserScore(login.getUserScore()+4);
										System.out.println("나는 깻잎을 잡아서 상대방의 친구를 도와주고 떼어진 깻잎 한 장을\n상대방의 밥그릇 위에 올려주었다.\n"
												+ "후후.. 꽤나 센스있는 행동인 것 같아\n"
												+ "상대방 : 아... 죄송한데 제가 깻잎 알러지가 있어요...\n"
												+ "나    :  오우....! 그러시군요.. 죄송해요..제가 다시 가져갈게요.");

									}else if(sesameLeaf == 2) {
										//모르는척
										login.setUserScore(login.getUserScore()+6);
										System.out.println("내가 괜히 떼어주는것 보단 모르는 체 하는게 낫겠어.\n"
												+ "결국 깻잎 두 장을 다 가져가는 상대방의 친구. 아무것도 안하길 다행이야.");
									}
								}else if(dinner == 2) {
									//파스타
									login.setUserScore(login.getUserScore()+4);
									System.out.println("나     : 파스타 잘 하는 집인데 진짜 맛있게 잘하거든요.\n\t 근데 예약도 안받고 웨이팅이 복불복이라서 기다려야 될지도 모르겠지만 일단 가시죠!\n"
											+ "상대방 : (예약도 안받고 웨이팅이 있을수도 있는 곳을 선택하다니. 센스가 없군)..아.. 네! 가죠!!");
									for(int i = 0; i <1; i++) {
										System.out.println("-------------------");
										try {
											Thread.sleep(2000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
										System.out.println("★☆식당 도착!☆★");
										System.out.println("-------------------\n");
									}
									System.out.print("파스타 맛집에 도착한 당신과 상대방.\n큰일이다! 대기팀이 176팀이다.\n"
											+ "나     : 아.. 이런 어쩌죠.. 오늘은 불복이네요..\n"
											+ "상대방 : 어쩔 수 없죠. 아니면 이 주변에 다른 식당으로 가는게 어때요?\n"
											+ "↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
											+ "1. 웨이팅한다. | 2. 다른 곳으로 간다. >>>");
									
									int waitOrNot = Integer.parseInt(sc.nextLine());
									
									if(waitOrNot == 1) {
										//웨이팅
										login.setUserScore(login.getUserScore()+0);
										System.out.println("나     : 아.. 근데 여기 바질페스토 파스타가 진짜 맛있거든요.\n\t 웨이팅 금방 빠질 것 같은데 조금만 더 기다려봐요..\n"
												+ "상대방 : 아 그럼 기다려보죠... 그럼 저... 잠시만 화장실 좀 갔다올게요!");
										for(int i = 0; i <5; i++) {
											System.out.println("..............................");
											try {
												Thread.sleep(1000);
											} catch (InterruptedException e) {
												e.printStackTrace();
											}
										}
										System.out.println("5분이 지나도 10분이 지나도 상대방은 돌아오지 않았다.\n당신의 센스없는 선택에 상대방은 도망가고 말았다."
												+ "\n소개팅 실패!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
											
											userService.updateSco(login);
											System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
											break;
									}else if(waitOrNot == 2){
										//다른곳
										login.setUserScore(login.getUserScore()+7);
										System.out.println("나     : 그러면 이 근처에 자반고등어 백반 잘 나오는 곳이 있거든요? 그쪽으로 가시죠!\n"
												+ "상대방 : 고등어 비린내 나고 좋죠! 반찬이 기대가 되네요.\n\t 빨리 가요! 맛있겠다!\n");
										for(int i = 0; i <1; i++) {
											System.out.println("-------------------");
											try {
												Thread.sleep(2000);
											} catch (InterruptedException e) {
												e.printStackTrace();
											}
											System.out.println("★☆식당 도착!☆★");
											System.out.println("-------------------\n");
										}
										System.out.println("식당에 도착하니 만석이다!\n 때마침 식당안에 상대방의 동성친구가 있는걸 상대방이 발견했다!!\n"
												+ "상대방은 친구와 나에게 합석이 괜찮은지를 물어보고 합석을 하게 되었다.\n"
												+ "상대방의 친구가 밑반찬으로 나온 깻잎장아찌를 못떼고 있다.\n나는 깻잎 떼는것을 도와줄 것인가? 못 본 체 할 것인가?");
										try {
											Thread.sleep(2000);
										} catch (InterruptedException e) {
											e.printStackTrace();
										} 
										System.out.println("↓↓↓↓↓나의 선택은?↓↓↓↓↓\n"
												+ "1. 도와주고 떼어진 깻잎을 상대방 밥그릇 위에 올려준다. | 2. 모르는 체 한다. >>>");
										
										int sesameLeaf = Integer.parseInt(sc.nextLine());
										
										if(sesameLeaf == 1) {
											//도와준다
											login.setUserScore(login.getUserScore()+3);
											System.out.println("나는 깻잎을 잡아서 상대방의 친구를 도와주고 떼어진 깻잎 한 장을\n상대방의 밥그릇 위에 올려주었다.\n"
													+ "후후.. 꽤나 센스있는 행동인 것 같아\n"
													+ "상대방 : 아... 죄송한데 제가 깻잎 알러지가 있어요...\n"
													+ "나    :  오우....! 그러시군요.. 죄송해요..제가 다시 가져갈게요.");

										}else if(sesameLeaf == 2) {
											//모르는척
											login.setUserScore(login.getUserScore()+6);
											System.out.println("내가 괜히 떼어주는것 보단 모르는 체 하는게 낫겠어.\n"
													+ "결국 깻잎 두 장을 다 가져가는 상대방의 친구. 아무것도 안하길 다행이야.");
										}
									}
									
								}
								System.out.println("==========================================================");
								System.out.println("\t\t\t저녁식사 후\t\t\t");
								System.out.println("==========================================================\n");
								try {
									Thread.sleep(800);
								} catch (InterruptedException e) {
									e.printStackTrace();
								} 
								System.out.println("상대방 : 오늘 재미있었어요~ 다음에도 볼 수 있었으면 좋겠어요! 그럼 안녕히 가세요.\n"
										+ "(꽤 만족스러운 소개팅이였다. 나름 괜찮은 선택들을 한 것 같아.\n나도 진정한 사랑을 얻을 수 있는건가..(두근)");
								userService.updateSco(login);
								System.out.println(login.getUserName() +"님의 점수 : " +login.getUserScore() + "점");
							}

						} else if (num == 2) {
							// 랭킹보기
							ArrayList<UsersVO> userList = userService.getUserList();
							for (int i = 0; i < userList.size(); i++) {
								System.out.println(userList.get(i));
							}

						} else if (num == 3) {
							// 종료하기

							System.out.println("종료합니다.");
							break;
						}

					}

				} else {
					System.out.println("로그인에 실패하였습니다.");
				}

			} else if (command == 3) {
				System.out.println("종료합니다.");
				break;
			}
		}

	}

}
