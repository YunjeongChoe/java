package main;

public class tt {

	public static void main(String[] args) {
		
		String star = "";
		for(int i = 0; i < 5; i++) {
			star += "*";
			System.out.println(star);
		}
		
		String star1 = "";
		for(int i = 0; i < 5; i++) {
			String blank = "";
			for(int j = 0; j < 5 - i; j++) {
				blank += " ";
			}
			star1 += "*";
			System.out.println(blank+star1);
		}
		
		String star2= "*";
		for(int i = 0; i < 5; i++) {
			String blank = "                     ";
			for(int j = 0; j < 5 -i; j++) {
				blank += " ";
			}
			System.out.println(blank+star2);
			star2 += "**";

		}
		
		
	}

}
