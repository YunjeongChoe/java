package model;

public class UsersVO {
	
	private String userId;
	private String userPassword;
	private String userName;
	private String userGender;
	private int userScore;
	
	
	public UsersVO() {
		
	}


	public UsersVO(String userId, String userPassword, String userName, String userGender, int userScore) {
		super();
		this.userId = userId;
		this.userPassword = userPassword;
		this.userName = userName;
		this.userGender = userGender;
		this.userScore = userScore;
	}


	@Override
	public String toString() {
		return "[이름: " + userName + " 성별: " + userGender + " 점수: " + userScore + "]";
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserGender() {
		return userGender;
	}


	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}


	public int getUserScore() {
		return userScore;
	}


	public void setUserScore(int userScore) {
		this.userScore = userScore;
	}
	
	
	
	
	
	
	
}
