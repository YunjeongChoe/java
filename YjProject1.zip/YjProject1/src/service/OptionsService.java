package service;

import dao.ResultDao;
import jdbc.ConnectionPool;

public class OptionsService {
	
	private ResultDao dao = ResultDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static OptionsService instance = new OptionsService();

	public static OptionsService getInstance() {
		return instance;
	}
	
	private OptionsService() {
		
	}
	
	
	
}
